/*
 * Leaflet-compatible lightweight map engine for this Android WebView app.
 * Implements only the APIs used by mapacalor.js, avoiding a large third-party runtime.
 * Tile source: OpenStreetMap (internet required for raster tiles).
 */
(function (global) {
  'use strict';

  const TILE = 256;
  const MAX_ZOOM = 19;
  const MIN_ZOOM = 2;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function normLng(lng) { return ((lng + 180) % 360 + 360) % 360 - 180; }
  function project(lat, lng, zoom) {
    const size = TILE * Math.pow(2, zoom);
    const x = (normLng(lng) + 180) / 360 * size;
    const s = Math.sin(lat * Math.PI / 180);
    const y = (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * size;
    return { x, y };
  }
  function unproject(x, y, zoom) {
    const size = TILE * Math.pow(2, zoom);
    const lng = x / size * 360 - 180;
    const n = Math.PI - 2 * Math.PI * y / size;
    const lat = 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
    return { lat, lng: normLng(lng) };
  }

  class Bounds {
    constructor(points) {
      const pts = Array.isArray(points) ? points : [];
      const flat = pts.flatMap(p => Array.isArray(p[0]) ? p : [p]);
      if (!flat.length) {
        this.minLat = this.maxLat = this.minLng = this.maxLng = 0;
        return;
      }
      this.minLat = this.maxLat = Number(flat[0][0]);
      this.minLng = this.maxLng = Number(flat[0][1]);
      flat.forEach(p => {
        this.minLat = Math.min(this.minLat, Number(p[0]));
        this.maxLat = Math.max(this.maxLat, Number(p[0]));
        this.minLng = Math.min(this.minLng, Number(p[1]));
        this.maxLng = Math.max(this.maxLng, Number(p[1]));
      });
    }
    getSouthWest() { return { lat: this.minLat, lng: this.minLng }; }
    getNorthEast() { return { lat: this.maxLat, lng: this.maxLng }; }
    isValid() { return [this.minLat,this.maxLat,this.minLng,this.maxLng].every(Number.isFinite); }
  }

  class LayerGroup {
    constructor() { this.map = null; this.layers = []; this._isOverlayGroup = true; }
    addTo(map) { this.map = map; map._groups.push(this); this.layers.forEach(l => l._addToMap?.(map)); return this; }
    addLayer(layer) { if (!this.layers.includes(layer)) this.layers.push(layer); if (this.map) layer._addToMap?.(this.map); return this; }
    removeLayer(layer) {
      const i = this.layers.indexOf(layer); if (i >= 0) this.layers.splice(i, 1);
      layer?._removeFromMap?.(); return this;
    }
    clearLayers() { this.layers.slice().forEach(l => l._removeFromMap?.()); this.layers = []; return this; }
  }

  class TileLayer {
    constructor(url, opts={}) { this.url=url; this.options=opts; this.map=null; this.pane=null; this._tiles=new global.Map(); }
    addTo(map) { this.map=map; map._tileLayers.push(this); this.pane=document.createElement('div'); this.pane.className='leaflet-tile-pane'; map._mapRoot.appendChild(this.pane); map._render(); return this; }
    _render(centerWorld) {
      if (!this.map || !this.pane) return;
      const z=this.map.zoom, tileSize=TILE;
      const center=centerWorld || project(this.map.center[0],this.map.center[1],z);
      const w=this.map._mapRoot.clientWidth || 360, h=this.map._mapRoot.clientHeight || 640;
      const minX=Math.floor((center.x-w/2)/tileSize)-1;
      const maxX=Math.floor((center.x+w/2)/tileSize)+1;
      const minY=Math.floor((center.y-h/2)/tileSize)-1;
      const maxY=Math.floor((center.y+h/2)/tileSize)+1;
      const keep=new Set();
      const worldTiles=Math.pow(2,z);
      for(let ty=minY; ty<=maxY; ty++){
        if(ty<0 || ty>=worldTiles) continue;
        for(let tx=minX; tx<=maxX; tx++){
          const wx=((tx%worldTiles)+worldTiles)%worldTiles;
          const key=`${z}/${wx}/${ty}`; keep.add(key);
          let img=this._tiles.get(key);
          if(!img){
            img=document.createElement('img'); img.className='leaflet-tile'; img.width=tileSize; img.height=tileSize; img.draggable=false; img.alt=''; img.decoding='async';
            img.src=this.url.replace('{z}',z).replace('{x}',wx).replace('{y}',ty).replace('{s}', ['a','b','c'][(wx+ty)%3]);
            img.addEventListener('error',()=>{img.style.opacity='0';});
            this.pane.appendChild(img); this._tiles.set(key,img);
          }
          img.style.left=(tx*tileSize-center.x+w/2)+'px';
          img.style.top=(ty*tileSize-center.y+h/2)+'px';
        }
      }
      for(const [key,img] of this._tiles){ if(!keep.has(key)){img.remove();this._tiles.delete(key);} }
    }
  }

  class Marker {
    constructor(latlng, opts={}) { this.latlng=[Number(latlng[0]),Number(latlng[1])]; this.options=opts; this.map=null; this.el=null; this.popup=null; }
    _ensure() {
      if(this.el) return;
      this.el=document.createElement('div'); this.el.className='leaflet-marker';
      const icon=this.options.icon;
      if(icon?.options){ this.el.className+=' '+(icon.options.className||''); this.el.innerHTML=icon.options.html||''; this.el.style.width=(icon.options.iconSize?.[0]||40)+'px'; this.el.style.height=(icon.options.iconSize?.[1]||40)+'px'; this.el.dataset.anchorX=icon.options.iconAnchor?.[0] ?? 20; this.el.dataset.anchorY=icon.options.iconAnchor?.[1] ?? 20; }
      else { this.el.innerHTML='📍'; this.el.style.fontSize='28px'; }
      this.el.addEventListener('click', e=>{e.stopPropagation(); if(this.popup) this.openPopup();});
    }
    _addToMap(map) { this.map=map; this._ensure(); if(!this.el.parentNode) map._markerPane.appendChild(this.el); map._renderOverlays(); }
    _removeFromMap(){ this.el?.remove(); if(this.popup?.el) this.popup.el.remove(); this.map=null; }
    addTo(layer){ layer.addLayer(this); return this; }
    setLatLng(ll){ this.latlng=[Number(ll[0]),Number(ll[1])]; this.map?._renderOverlays(); return this; }
    bindPopup(html){ this.popup={html,el:null}; return this; }
    openPopup(){ if(!this.map || !this.popup) return this; if(this.popup.el) this.popup.el.remove(); const p=document.createElement('div'); p.className='leaflet-popup'; p.innerHTML=this.popup.html; this.map._popupPane.appendChild(p); const pos=this.map._pointFor(this.latlng); p.style.left=(pos.x+10)+'px'; p.style.top=(pos.y-12-Math.min(120,p.offsetHeight||50))+'px'; this.popup.el=p; return this; }
  }

  class Polyline {
    constructor(latlngs, opts={}){ this.latlngs=latlngs||[]; this.options=opts; this.map=null; this.el=null; }
    _addToMap(map){ this.map=map; if(!this.el){this.el=document.createElementNS('http://www.w3.org/2000/svg','polyline'); this.el.setAttribute('fill','none'); this.el.setAttribute('stroke-linecap','round'); this.el.setAttribute('stroke-linejoin','round');} if(!this.el.parentNode) map._svg.appendChild(this.el); this.el.setAttribute('stroke',this.options.color||'#2563eb'); this.el.setAttribute('stroke-width',this.options.weight||5); this.el.setAttribute('stroke-opacity',this.options.opacity ?? 1); if(this.options.dashArray) this.el.setAttribute('stroke-dasharray',this.options.dashArray); map._renderOverlays(); }
    _removeFromMap(){ this.el?.remove(); this.map=null; }
  }

  class VFMap {
    constructor(el, opts={}){
      this._mapRoot=typeof el==='string'?document.getElementById(el):el; if(!this._mapRoot) throw new Error('Map container not found');
      this.center=(opts.center||[0,0]).slice(); this.zoom=Number(opts.zoom||14); this._handlers={}; this._groups=[]; this._tileLayers=[]; this._drag=null;
      this._mapRoot.classList.add('leaflet-container'); this._mapRoot.innerHTML='';
      this._markerPane=document.createElement('div'); this._markerPane.className='leaflet-marker-pane pane';
      this._popupPane=document.createElement('div'); this._popupPane.className='leaflet-popup-pane pane';
      this._mapRoot.appendChild(this._markerPane); this._mapRoot.appendChild(this._popupPane);
      this._svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); this._svg.classList.add('leaflet-overlay-svg'); this._mapRoot.insertBefore(this._svg,this._markerPane); 
      this._overlayPane=this._svg;
      if(opts.zoomControl!==false) this._addControls();
      if(opts.attributionControl!==false) this._addAttribution();
      this._bindPointer(); setTimeout(()=>this._render(),0);
    }
    _addControls(){ const c=document.createElement('div'); c.className='leaflet-control-container'; const z=document.createElement('div'); z.className='leaflet-control-zoom'; const plus=document.createElement('button'); plus.textContent='+'; plus.type='button'; const minus=document.createElement('button'); minus.textContent='−'; minus.type='button'; plus.onclick=()=>this.setView(this.center,this.zoom+1,{animate:false}); minus.onclick=()=>this.setView(this.center,this.zoom-1,{animate:false}); z.append(plus,minus); c.appendChild(z); this._mapRoot.appendChild(c); }
    _addAttribution(){ const a=document.createElement('div'); a.className='leaflet-control-attribution'; a.innerHTML='© OpenStreetMap contributors'; this._mapRoot.appendChild(a); }
    _bindPointer(){
      const el=this._mapRoot;
      el.addEventListener('pointerdown',e=>{ if(e.target?.closest?.('.leaflet-control-container,.leaflet-popup')) return; if(e.button!==0 && e.pointerType==='mouse') return; const rect=el.getBoundingClientRect(); const p=this._pointToWorld(e.clientX-rect.left,e.clientY-rect.top); this._drag={sx:e.clientX,sy:e.clientY,cx:p.x,cy:p.y,moved:false}; el.setPointerCapture?.(e.pointerId); });
      el.addEventListener('pointermove',e=>{ if(!this._drag)return; const dx=e.clientX-this._drag.sx,dy=e.clientY-this._drag.sy; if(Math.abs(dx)+Math.abs(dy)>5)this._drag.moved=true; if(!this._drag.moved)return; const rect=el.getBoundingClientRect(); const world={x:this._drag.cx-dx,y:this._drag.cy-dy}; const inv=unproject(world.x,world.y,this.zoom); this.center=[inv.lat,inv.lng]; this._render(); });
      el.addEventListener('pointerup',e=>{ if(e.target?.closest?.('.leaflet-control-container,.leaflet-popup')) { this._drag=null; return; } const d=this._drag; this._drag=null; if(!d || d.moved)return; const rect=el.getBoundingClientRect(); const ll=this._latLngFromPoint(e.clientX-rect.left,e.clientY-rect.top); this._emit('click',{latlng:{lat:ll.lat,lng:ll.lng}}); });
      el.addEventListener('wheel',e=>{ if(e.target?.closest?.('.leaflet-control-container,.leaflet-popup')) return; e.preventDefault(); this.setView(this.center,this.zoom+(e.deltaY<0?1:-1),{animate:false}); },{passive:false});
    }
    on(name,fn){(this._handlers[name]||(this._handlers[name]=[])).push(fn);return this;}
    _emit(name,arg){(this._handlers[name]||[]).forEach(fn=>{try{fn(arg)}catch(e){setTimeout(()=>{throw e},0)}})}
    getContainer(){return this._mapRoot;}
    getZoom(){return this.zoom;}
    // Compatibilidade com o painel ao mudar tamanho/visibilidade da área do mapa.
    invalidateSize(){ this._render(); return this; }
    setView(center,zoom=this.zoom){ this.center=[Number(center[0]),Number(center[1])]; this.zoom=clamp(Math.round(Number(zoom)),MIN_ZOOM,MAX_ZOOM); this._render(); return this; }
    panTo(center,opts){ return this.setView(center,this.zoom,opts); }
    fitBounds(bounds,opts={}){ const b=bounds instanceof Bounds?bounds:new Bounds(bounds); const sw=b.getSouthWest(), ne=b.getNorthEast(); const lat=(sw.lat+ne.lat)/2,lng=(sw.lng+ne.lng)/2; const w=Math.max(1,(Math.abs(project(lat,ne.lng,MIN_ZOOM).x-project(lat,sw.lng,MIN_ZOOM).x))); const h=Math.max(1,(Math.abs(project(ne.lat,lng,MIN_ZOOM).y-project(sw.lat,lng,MIN_ZOOM).y))); const availW=Math.max(120,(this._mapRoot.clientWidth||360)-(opts.padding?.[0]||40)*2); const availH=Math.max(120,(this._mapRoot.clientHeight||640)-(opts.padding?.[1]||40)*2); let z=Math.floor(Math.min(Math.log2(availW/w),Math.log2(availH/h)))+MIN_ZOOM; if(!Number.isFinite(z))z=14; return this.setView([lat,lng],clamp(z,MIN_ZOOM,Math.min(MAX_ZOOM, Number.isFinite(Number(opts.maxZoom)) ? Number(opts.maxZoom) : MAX_ZOOM)),opts); }
    _pointToWorld(x,y){ const c=project(this.center[0],this.center[1],this.zoom); const w=this._mapRoot.clientWidth||360,h=this._mapRoot.clientHeight||640; return {x:c.x+(x-w/2),y:c.y+(y-h/2)}; }
    _latLngFromPoint(x,y){ const p=this._pointToWorld(x,y); return unproject(p.x,p.y,this.zoom); }
    _pointFor(ll){ const c=project(this.center[0],this.center[1],this.zoom); const p=project(ll[0],ll[1],this.zoom); const w=this._mapRoot.clientWidth||360,h=this._mapRoot.clientHeight||640; return {x:p.x-c.x+w/2,y:p.y-c.y+h/2}; }
    _render(){ const c=project(this.center[0],this.center[1],this.zoom); this._tileLayers.forEach(t=>t._render(c)); this._renderOverlays(); }
    _renderOverlays(){
      // V22.3.1: evita reentrada recursiva. Marker/Polyline chamam _renderOverlays
      // ao serem anexados e, sem esta trava, um histórico com pontos do mapa
      // de calor podia causar recursão infinita e derrubar o WebView.
      if(this._renderingOverlays) return;
      this._renderingOverlays=true;
      try {
        const w=this._mapRoot.clientWidth||360,h=this._mapRoot.clientHeight||640;
        this._svg.setAttribute('width',w);this._svg.setAttribute('height',h);this._svg.setAttribute('viewBox',`0 0 ${w} ${h}`);
        this._groups.forEach(g=>g.layers.forEach(layer=>{
          if(layer instanceof Marker){layer._addToMap(this);const p=this._pointFor(layer.latlng);const ax=Number(layer.el.dataset.anchorX||0),ay=Number(layer.el.dataset.anchorY||0);layer.el.style.transform=`translate(${p.x-ax}px,${p.y-ay}px)`;layer.el.style.zIndex=layer.options.zIndexOffset||500; if(layer.popup?.el){layer.popup.el.style.left=(p.x+10)+'px';}}
          else if(layer instanceof Polyline){layer._addToMap(this);const pts=layer.latlngs.map(ll=>{const p=this._pointFor(ll);return `${p.x},${p.y}`}).join(' ');layer.el.setAttribute('points',pts);}
        }));
      } finally {
        this._renderingOverlays=false;
      }
    }
  }

  const L={
    map:(el,opts)=>new VFMap(el,opts),
    tileLayer:(url,opts)=>new TileLayer(url,opts),
    layerGroup:()=>new LayerGroup(),
    marker:(ll,opts)=>new Marker(ll,opts),
    polyline:(lls,opts)=>new Polyline(lls,opts),
    divIcon:(opts)=>({options:opts||{}}),
    latLngBounds:(points)=>new Bounds(points)
  };
  global.L=L;
})(window);
