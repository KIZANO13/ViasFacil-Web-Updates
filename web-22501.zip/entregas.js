/* Modelo central de Entrega - Painel do Motorista
 * Compatível com o antigo formato de registros/rotas.
 * Não depende de frameworks.
 */
(function () {
    'use strict';

    const DB_KEY = 'painel-db';
    const SCHEMA_VERSION = 7;
    const ACTIVE_GPS_KEY = 'painel-entrega-gps-atual';

    function agora() {
        const d = new Date();
        return {
            iso: d.toISOString(),
            data: d.toLocaleDateString('pt-BR'),
            hora: d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        };
    }

    function numero(v, fallback = 0) {
        const n = Number(v);
        return Number.isFinite(n) ? n : fallback;
    }

    function valorMoeda(v) {
        if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
        const texto = String(v ?? '').replace(/R\$\s?/g, '').trim();
        if (!texto) return 0;
        const normalizado = texto.includes(',')
            ? texto.replace(/\./g, '').replace(',', '.')
            : texto;
        const n = Number(normalizado);
        return Number.isFinite(n) ? n : 0;
    }

    function tempoValido(v) {
        return /^(?:\d{1,3}):[0-5]\d$/.test(String(v ?? '').trim());
    }

    function minutosDeTempo(v) {
        if (typeof v === 'number') return Number.isFinite(v) && v >= 0 ? v : 0;
        if (!tempoValido(v)) return 0;
        const [h, m] = String(v).trim().split(':').map(Number);
        return h * 60 + m;
    }

    function formatarTempo(min) {
        const total = Math.max(0, Math.round(numero(min)));
        const h = Math.floor(total / 60);
        const m = total % 60;
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    }

    function calcularIndicadores(entrega) {
        const valor = numero(entrega.valor);
        const km = numero(entrega.kmReal || entrega.kmEstimado || entrega.km);
        const minutos = numero(entrega.tempoRealMin || entrega.tempoEstimadoMin || minutosDeTempo(entrega.tempo));
        entrega.valorPorKm = km > 0 ? Number((valor / km).toFixed(2)) : 0;
        entrega.valorPorHora = minutos > 0 ? Number((valor / (minutos / 60)).toFixed(2)) : 0;
        return entrega;
    }

    function normalizarEntrega(raw = {}) {
        const t = agora();
        const kmEstimado = numero(raw.kmEstimado ?? raw.km);
        const tempoEstimadoMin = numero(raw.tempoEstimadoMin ?? minutosDeTempo(raw.tempo));
        const kmReal = raw.kmReal != null ? numero(raw.kmReal) : 0;
        const tempoRealMin = raw.tempoRealMin != null ? numero(raw.tempoRealMin) : 0;

        const entrega = {
            id: raw.id ?? raw.criadoEm ?? `ent_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, 
            origemSistema: raw.origemSistema || raw.origem || 'manual',
            status: raw.status || 'finalizada',
            estabelecimento: raw.estabelecimento || '',
            enderecoColeta: raw.enderecoColeta || raw.origem || '',
            enderecoEntrega: raw.enderecoEntrega || raw.destino || '',
            valor: valorMoeda(raw.valor),

            kmEstimado,
            tempoEstimadoMin,
            tempoEstimado: raw.tempoEstimado || formatarTempo(tempoEstimadoMin),

            kmReal,
            tempoRealMin,
            tempoReal: raw.tempoReal || (tempoRealMin ? formatarTempo(tempoRealMin) : ''),

            // V17 - separação entre deslocamento até a coleta e trecho da entrega.
            kmAteColetaReal: numero(raw.kmAteColetaReal),
            kmEntregaReal: numero(raw.kmEntregaReal),
            tempoColetaRealMin: numero(raw.tempoColetaRealMin),
            tempoEntregaRealMin: numero(raw.tempoEntregaRealMin),

            latColeta: raw.latColeta ?? raw.latOrigem ?? null,
            lngColeta: raw.lngColeta ?? raw.lngOrigem ?? null,
            latEntrega: raw.latEntrega ?? raw.latDestino ?? null,
            lngEntrega: raw.lngEntrega ?? raw.lngDestino ?? null,

            velocidadeMaxima: numero(raw.velocidadeMaxima ?? raw.velMax),
            valorPorKmReal: numero(raw.valorPorKmReal),
            valorPorHoraReal: numero(raw.valorPorHoraReal),
            score: raw.score != null ? numero(raw.score) : null,
            // Dados antigos com id/data não recebem automaticamente a data de hoje.
            data: raw.data || (raw.id == null ? t.data : ''),
            hora: raw.hora || (raw.id == null ? t.hora : ''),
            criadoEm: raw.criadoEm ?? (raw.id == null && !raw.data ? t.iso : null),
            capturadoEm: raw.capturadoEm ?? null,
            aceitaEm: raw.aceitaEm ?? null,
            navegacaoIniciadaEm: raw.navegacaoIniciadaEm ?? null,
            coletaRealizadaEm: raw.coletaRealizadaEm ?? null,
            entregaFinalizadaEm: raw.entregaFinalizadaEm ?? null,
            finalizadoEm: raw.finalizadoEm || null,
            trajeto: Array.isArray(raw.trajeto) ? raw.trajeto : [],

            // Compatibilidade com o painel antigo
            origem: raw.enderecoColeta || raw.origem || '',
            destino: raw.enderecoEntrega || raw.destino || '',
            km: kmReal || kmEstimado,
            tempo: raw.tempoReal || raw.tempoEstimado || raw.tempo || '00:00',
            velMax: numero(raw.velocidadeMaxima ?? raw.velMax)
        };

        return calcularIndicadores(entrega);
    }

    function migrarRegistroAntigo(r, origem = 'legacy') {
        return normalizarEntrega({
            ...r,
            id: r.id,
            origemSistema: origem,
            status: r.status || 'finalizada',
            estabelecimento: r.estabelecimento || '',
            enderecoColeta: r.enderecoColeta || r.origem || '',
            enderecoEntrega: r.enderecoEntrega || r.destino || '',
            kmEstimado: r.kmEstimado ?? r.km,
            tempoEstimadoMin: r.tempoEstimadoMin ?? minutosDeTempo(r.tempo),
            kmReal: r.kmReal ?? r.km,
            tempoRealMin: r.tempoRealMin ?? minutosDeTempo(r.tempo),
            valor: r.valor || 0,
            data: r.data,
            hora: r.hora,
            velocidadeMaxima: r.velocidadeMaxima ?? r.velMax
        });
    }

    function carregarDB() {
        let db;
        try {
            db = JSON.parse(localStorage.getItem(DB_KEY) || '{}');
        } catch (_) {
            db = {};
        }
        if (!db || typeof db !== 'object') db = {};

        const entregasExistentes = Array.isArray(db.entregas) ? db.entregas : [];
        const registrosAntigos = Array.isArray(db.registros) ? db.registros : [];
        const rotasAntigas = Array.isArray(db.rotas) ? db.rotas : [];

        if (!entregasExistentes.length && registrosAntigos.length) {
            db.entregas = registrosAntigos.map(r => migrarRegistroAntigo(r));
        } else {
            db.entregas = entregasExistentes.map(normalizarEntrega);
        }

        db.estabelecimentos = Array.isArray(db.estabelecimentos) ? db.estabelecimentos : [];
        db.rotas = Array.isArray(db.rotas) ? db.rotas : rotasAntigas;
        db.metaKm = numero(db.metaKm, 500);
        db.configuracoes = db.configuracoes && typeof db.configuracoes === 'object' ? db.configuracoes : {};
        // Migração única: remove configuração de filtro e cópia redundante de registros.
        const tinhaFiltroLegado = Object.prototype.hasOwnProperty.call(db.configuracoes, 'filtro99');
        const precisaMigrarFormato = Number(db.schemaVersion || 0) < SCHEMA_VERSION || Array.isArray(db.registros);
        if (tinhaFiltroLegado) delete db.configuracoes.filtro99;
        db.schemaVersion = SCHEMA_VERSION;
        if (tinhaFiltroLegado || precisaMigrarFormato) {
            try {
                const persistente = { ...db };
                delete persistente.registros;
                localStorage.setItem(DB_KEY, JSON.stringify(persistente));
            } catch (e) { console.warn('Não foi possível migrar o banco local.', e); }
        }

        // Alias apenas em memória para compatibilidade, sem duplicar o JSON salvo.
        db.registros = db.entregas;
        return db;
    }

    function salvarDB(db) {
        const novo = { ...db, schemaVersion: SCHEMA_VERSION };
        novo.entregas = Array.isArray(novo.entregas) ? novo.entregas.map(normalizarEntrega) : [];
        delete novo.registros;
        localStorage.setItem(DB_KEY, JSON.stringify(novo));
        novo.registros = novo.entregas;
        return novo;
    }

    function adicionarEntrega(raw) {
        const db = carregarDB();
        const entrega = normalizarEntrega(raw);
        db.entregas = Array.isArray(db.entregas) ? db.entregas : [];
        db.entregas.unshift(entrega);
        db.registros = db.entregas;
        salvarDB(db);
        return entrega;
    }

    function atualizarEntrega(id, patch) {
        const db = carregarDB();
        const idx = db.entregas.findIndex(e => String(e.id) === String(id));
        if (idx < 0) return null;
        const merged = { ...db.entregas[idx] };
        Object.entries(patch || {}).forEach(([key, value]) => { if (value !== undefined) merged[key] = value; });
        db.entregas[idx] = normalizarEntrega(merged);
        salvarDB(db);
        return db.entregas[idx];
    }

    function obterEntrega(id) {
        return carregarDB().entregas.find(e => String(e.id) === String(id)) || null;
    }

    function atualizarDadosGPS(raw) {
        const id = raw?.entregaId ?? raw?.id ?? null;
        if (!id) return aceitarDadosGPSLegado(raw);

        const existente = obterEntrega(id);
        if (existente && ['finalizada', 'concluida', 'concluída'].includes(String(existente.status).toLowerCase())) {
            clearActiveGpsDelivery(id);
            return existente; // Callback repetido não altera uma entrega já concluída.
        }
        const atualizada = atualizarEntrega(id, {
            origemSistema: raw.origemSistema || 'gps',
            status: raw.status || 'finalizada',
            estabelecimento: raw.estabelecimento || undefined,
            enderecoColeta: raw.enderecoColeta || raw.origem || undefined,
            enderecoEntrega: raw.enderecoEntrega || raw.destino || undefined,
            valor: raw.valor != null ? raw.valor : undefined,
            kmEstimado: raw.kmEstimado != null ? raw.kmEstimado : undefined,
            tempoEstimadoMin: raw.tempoEstimadoMin != null ? raw.tempoEstimadoMin : undefined,
            tempoEstimado: raw.tempoEstimado || undefined,
            kmReal: raw.kmReal != null ? raw.kmReal : undefined,
            tempoRealMin: raw.tempoRealMin != null ? raw.tempoRealMin : undefined,
            tempoReal: raw.tempoReal || undefined,
            latColeta: raw.latColeta ?? undefined,
            lngColeta: raw.lngColeta ?? undefined,
            latEntrega: raw.latEntrega ?? undefined,
            lngEntrega: raw.lngEntrega ?? undefined,
            velocidadeMaxima: raw.velocidadeMaxima ?? undefined,
            trajeto: raw.trajeto || undefined,
            finalizadoEm: raw.finalizadoEm || new Date().toISOString()
        });
        clearActiveGpsDelivery(id);
        return atualizada;
    }

    function aceitarDadosGPSLegado(raw) {
        return adicionarEntrega({
            ...raw,
            origemSistema: raw.origemSistema || 'gps',
            status: raw.status || 'finalizada',
            enderecoColeta: raw.enderecoColeta || raw.origem,
            enderecoEntrega: raw.enderecoEntrega || raw.destino,
            kmReal: raw.kmReal ?? raw.km,
            tempoRealMin: raw.tempoRealMin ?? minutosDeTempo(raw.tempo),
            finalizadoEm: raw.finalizadoEm || new Date().toISOString()
        });
    }


    const ICONES_ESTABELECIMENTO = ['🍔','🍕','🍣','🌮','🍗','🥗','☕','🍰','🍜','🥪','🍟','🍛','🍩','🧁','🥤','🍽️','🏪','⭐','📍'];

    function coordenada(v, limite) {
        if (v === null || v === undefined || String(v).trim() === '') return null;
        const n = Number(v);
        return Number.isFinite(n) && Math.abs(n) <= limite ? n : null;
    }
    function posicaoValida(lat, lng) {
        return lat !== null && lng !== null && !(lat === 0 && lng === 0);
    }
    function identidade(v) {
        return String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .trim().replace(/\s+/g, ' ').toLowerCase();
    }
    function distanciaHaversineLocal(lat1, lng1, lat2, lng2) {
        const p1 = coordenada(lat1, 90), q1 = coordenada(lng1, 180);
        const p2 = coordenada(lat2, 90), q2 = coordenada(lng2, 180);
        if (!posicaoValida(p1, q1) || !posicaoValida(p2, q2)) return Infinity;
        const R = 6371;
        const dLat = (p2-p1) * Math.PI / 180;
        const dLng = (q2-q1) * Math.PI / 180;
        const a = Math.sin(dLat/2)**2 + Math.cos(p1*Math.PI/180)*Math.cos(p2*Math.PI/180)*Math.sin(dLng/2)**2;
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    function salvarRestauranteDaEntrega(entrega, extras = {}) {
        const nome = String(extras.nome ?? entrega?.estabelecimento ?? '').trim();
        const endereco = String(extras.endereco ?? entrega?.enderecoColeta ?? '').trim();
        const lat = coordenada(extras.lat ?? entrega?.latColeta, 90);
        const lng = coordenada(extras.lng ?? entrega?.lngColeta, 180);
        const temPosicao = posicaoValida(lat, lng);
        if (!nome && !endereco && !temPosicao) return null;

        const db = carregarDB();
        db.estabelecimentos = Array.isArray(db.estabelecimentos) ? db.estabelecimentos : [];
        const idx = db.estabelecimentos.findIndex(e => {
            const mesmoNome = !!nome && identidade(e.nome) === identidade(nome);
            const mesmoEndereco = !!endereco && identidade(e.endereco) === identidade(endereco);
            const mesmaPosicao = temPosicao && distanciaHaversineLocal(lat, lng, e.lat, e.lng) <= 0.12;
            // Nomes diferentes nunca são mesclados apenas por coordenadas.
            if (nome && e.nome && !mesmoNome) return false;
            if (mesmoNome && (mesmoEndereco || mesmaPosicao)) return true;
            if (mesmoNome && !endereco && !e.endereco && !temPosicao && !posicaoValida(coordenada(e.lat, 90), coordenada(e.lng, 180))) return true;
            if (!nome && mesmoEndereco) return true;
            return !nome && !endereco && !e.nome && !e.endereco && mesmaPosicao;
        });

        const atual = idx >= 0 ? db.estabelecimentos[idx] : {};
        const notas = Array.isArray(atual.avaliacoes) ? atual.avaliacoes : [];
        const totalAntes = Number(atual.totalEntregas || 0);
        const valorAntes = Number(atual.somaValores || 0);
        const novo = {
            id: atual.id || extras.id || `est_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
            nome: nome || atual.nome || 'Restaurante',
            endereco: endereco || atual.endereco || '',
            lat: temPosicao ? lat : atual.lat ?? null,
            lng: temPosicao ? lng : atual.lng ?? null,
            icone: extras.icone || atual.icone || '🍽️',
            nota: notas.length ? Number((notas.reduce((a,b)=>a+Number(b),0)/notas.length).toFixed(1)) : Number(atual.nota || 0) || null,
            avaliacoes: notas,
            totalEntregas: totalAntes + 1,
            somaValores: Number((valorAntes + Number(entrega?.valor || 0)).toFixed(2)),
            ultimaEntrega: new Date().toISOString(),
            observacoes: atual.observacoes || ''
        };
        if (idx >= 0) db.estabelecimentos[idx] = novo; else db.estabelecimentos.unshift(novo);
        salvarDB(db);
        return novo;
    }

    function adicionarAvaliacaoEstabelecimento(id, nota, observacao = '') {
        const db = carregarDB();
        const idx = (db.estabelecimentos || []).findIndex(e => String(e.id) === String(id));
        if (idx < 0) return null;
        const valor = Math.max(1, Math.min(5, Number(nota) || 0));
        if (!valor) return db.estabelecimentos[idx];
        const e = db.estabelecimentos[idx];
        e.avaliacoes = Array.isArray(e.avaliacoes) ? e.avaliacoes : [];
        e.avaliacoes.push(valor);
        e.avaliacoes = e.avaliacoes.slice(-50);
        e.nota = Number((e.avaliacoes.reduce((a,b)=>a+Number(b),0) / e.avaliacoes.length).toFixed(1));
        if (observacao.trim()) e.observacoes = observacao.trim();
        salvarDB(db);
        return e;
    }

    function atualizarEstabelecimento(id, patch = {}) {
        const db = carregarDB();
        const idx = (db.estabelecimentos || []).findIndex(e => String(e.id) === String(id));
        if (idx < 0) return null;
        db.estabelecimentos[idx] = { ...db.estabelecimentos[idx], ...patch };
        salvarDB(db);
        return db.estabelecimentos[idx];
    }
    function definirEntregaGPSAtual(id) {
        if (!id) { localStorage.removeItem(ACTIVE_GPS_KEY); return; }
        localStorage.setItem(ACTIVE_GPS_KEY, String(id));
    }

    function obterEntregaGPSAtual() {
        const id = localStorage.getItem(ACTIVE_GPS_KEY);
        return id ? obterEntrega(id) : null;
    }

    function obterIdEntregaGPSAtual() {
        return localStorage.getItem(ACTIVE_GPS_KEY) || null;
    }

    function clearActiveGpsDelivery(id = null) {
        const atual = localStorage.getItem(ACTIVE_GPS_KEY);
        if (id == null || String(atual) === String(id)) localStorage.removeItem(ACTIVE_GPS_KEY);
    }

    function abrirEntregaNoGPS(id) {
        const entrega = obterEntrega(id);
        if (!entrega) return null;
        if (['finalizada', 'concluida', 'concluída'].includes(String(entrega.status).toLowerCase())) return null;
        definirEntregaGPSAtual(entrega.id);
        return entrega;
    }


    /**
     * Confirma cancelamento nativo: remove apenas o registro ainda pendente,
     * sem apagar entregas finalizadas, histórico ou configurações.
     */
    function confirmarCancelamentoNativo(id) {
        if (typeof id !== 'string' || !id) return false;
        const db = carregarDB();
        const keep = db.entregas.filter(e => String(e.id) !== id ||
            ['finalizada', 'concluida', 'concluída'].includes(String(e.status).toLowerCase()));
        if (keep.length !== db.entregas.length) {
            db.entregas = keep;
            salvarDB(db); // Só confirma depois que a persistência terminar.
        }
        clearActiveGpsDelivery(id);
        return true;
    }

    function importarEntregaNativa(jsonOrString) {
        try {
            const raw = typeof jsonOrString === 'string' ? JSON.parse(jsonOrString) : jsonOrString || {};
            const existente = raw.id ? obterEntrega(raw.id) : null;
            const entrega = normalizarEntrega({
                ...raw,
                id: raw.id || `native_${raw.entregaFinalizadaEm || Date.now()}`,
                origemSistema: raw.origemSistema || 'manual',
                status: raw.status || 'finalizada',
                latColeta: raw.latColeta ?? null,
                lngColeta: raw.lngColeta ?? null
            });
            if (existente && ['finalizada', 'concluida', 'concluída'].includes(String(existente.status).toLowerCase())) {
                // Sincronização repetida não regrava um registro finalizado.
                clearActiveGpsDelivery(existente.id);
                return existente;
            }
            if (existente) atualizarEntrega(entrega.id, entrega);
            else adicionarEntrega(entrega);
            localStorage.removeItem(ACTIVE_GPS_KEY);
            return entrega;
        } catch (e) {
            console.warn('Falha ao importar entrega nativa:', e);
            return null;
        }
    }

    function obterEstatisticasRestaurante(nome, lat, lng) {
        const db = carregarDB();
        const items = Array.isArray(db.estabelecimentos) ? db.estabelecimentos : [];
        const alvo = items.find(e => {
            const mesmoNome = !!nome && identidade(e.nome) === identidade(nome);
            const filtroPorPosicao = posicaoValida(coordenada(lat, 90), coordenada(lng, 180));
            const mesmaPos = distanciaHaversineLocal(lat, lng, e.lat, e.lng) <= 0.12;
            // Sem endereço no contrato desta API, nome só é suficiente sem posição.
            return mesmoNome && (!filtroPorPosicao || mesmaPos);
        });
        if (!alvo) return null;
        return {
            id: alvo.id,
            nome: alvo.nome || 'Restaurante',
            endereco: alvo.endereco || '',
            totalRetiradas: Number(alvo.totalEntregas || 0),
            valorMedio: Number(alvo.totalEntregas || 0) > 0 ? Number(alvo.somaValores || 0) / Number(alvo.totalEntregas || 0) : 0,
            tempoMedioMin: Number(alvo.tempoMedioMin || 0)
        };
    }
    // Compatibilidade com chamadas nativas antigas; a V17 usa window.EntregaDB diretamente.
    window.importarEntregaNativa = importarEntregaNativa;

    window.EntregaDB = {
        DB_KEY,
        SCHEMA_VERSION,
        agora,
        numero,
        minutosDeTempo,
        tempoValido,
        formatarTempo,
        calcularIndicadores,
        normalizarEntrega,
        migrarRegistroAntigo,
        carregarDB,
        salvarDB,
        adicionarEntrega,
        atualizarEntrega,
        obterEntrega,
        aceitarDadosGPS: aceitarDadosGPSLegado,
        atualizarDadosGPS,
        definirEntregaGPSAtual,
        obterEntregaGPSAtual,
        obterIdEntregaGPSAtual,
        clearActiveGpsDelivery,
        abrirEntregaNoGPS,
        confirmarCancelamentoNativo,
        importarEntregaNativa,
        obterEstatisticasRestaurante,
        salvarRestauranteDaEntrega,
        adicionarAvaliacaoEstabelecimento,
        atualizarEstabelecimento,
        ICONES_ESTABELECIMENTO
    };
}());
