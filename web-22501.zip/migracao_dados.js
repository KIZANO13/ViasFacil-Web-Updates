/* V22.4.1: arquivo de compatibilidade com a origem legada.
   Em HTTPS a Activity fornece uma resposta privada para migrar localStorage. */
