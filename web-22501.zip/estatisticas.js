/* V20 - Estatísticas e desempenho do entregador
 * Funções puras para transformar o histórico de entregas em indicadores.
 */
(function () {
    'use strict';

    const DIAS_SEMANA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

    function numero(v, fallback = 0) {
        const n = Number(v);
        return Number.isFinite(n) ? n : fallback;
    }

    function inicioDoDia(d = new Date()) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    }

    function dataDaEntrega(entrega) {
        // A data visível antiga é a referência quando não há conclusão nativa.
        // Evita que registros legados sem criadoEm apareçam como entregas de hoje.
        for (const valor of [entrega?.entregaFinalizadaEm, entrega?.finalizadoEm]) {
            if (valor == null || valor === '') continue;
            const d = new Date(valor);
            if (Number.isFinite(d.getTime())) return d;
        }
        const data = String(entrega?.data || '').trim();
        const hora = String(entrega?.hora || '00:00').trim();
        const m = data.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
        if (m) {
            const hm = hora.match(/^(\d{1,2}):([0-5]\d)$/);
            const h = hm ? Number(hm[1]) : 0;
            const min = hm ? Number(hm[2]) : 0;
            const ano = Number(m[3]), mes = Number(m[2]) - 1, dia = Number(m[1]);
            const d = new Date(ano, mes, dia, h, min);
            if (d.getFullYear() === ano && d.getMonth() === mes && d.getDate() === dia && h < 24) return d;
        }
        for (const valor of [entrega?.coletaRealizadaEm, entrega?.criadoEm]) {
            if (valor == null || valor === '') continue;
            const d = new Date(valor);
            if (Number.isFinite(d.getTime())) return d;
        }
        return null;
    }

    function somenteFinalizadas(entregas) {
        return (Array.isArray(entregas) ? entregas : []).filter(e => {
            const status = String(e?.status || 'finalizada').toLowerCase();
            return status === 'finalizada' || status === 'concluida' || status === 'concluída';
        });
    }

    function kmEntrega(e) {
        const real = numero(e?.kmReal);
        return real > 0 ? real : numero(e?.kmEstimado ?? e?.km);
    }

    function tempoEntregaMin(e) {
        const real = numero(e?.tempoRealMin);
        return real > 0 ? real : numero(e?.tempoEstimadoMin);
    }

    function resumo(entregas) {
        const lista = somenteFinalizadas(entregas);
        const faturamento = lista.reduce((s, e) => s + numero(e?.valor), 0);
        const km = lista.reduce((s, e) => s + kmEntrega(e), 0);
        const minutos = lista.reduce((s, e) => s + tempoEntregaMin(e), 0);
        const velocidadeMaxima = lista.reduce((m, e) => Math.max(m, numero(e?.velocidadeMaxima ?? e?.velMax)), 0);
        const entregasQtd = lista.length;
        const ticketMedio = entregasQtd ? faturamento / entregasQtd : 0;
        const valorPorKm = km > 0 ? faturamento / km : 0;
        const valorPorHora = minutos > 0 ? faturamento / (minutos / 60) : 0;
        const velocidadeMedia = minutos > 0 ? km / (minutos / 60) : 0;
        const diasAtivos = new Set(lista.map(e => {
            const d = dataDaEntrega(e);
            return d ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}` : '';
        }).filter(Boolean)).size;

        return {
            faturamento,
            entregas: entregasQtd,
            km,
            minutos,
            ticketMedio,
            valorPorKm,
            valorPorHora,
            velocidadeMaxima,
            velocidadeMedia,
            diasAtivos
        };
    }

    function filtrarPeriodo(entregas, periodo, agora = new Date()) {
        const lista = somenteFinalizadas(entregas);
        if (periodo === 'tudo') return lista;

        const hoje = inicioDoDia(agora);
        let inicio = hoje;
        let fim = new Date(hoje);
        fim.setDate(fim.getDate() + 1);

        if (periodo === '7d') {
            inicio = new Date(hoje);
            inicio.setDate(inicio.getDate() - 6);
        } else if (periodo === '30d') {
            inicio = new Date(hoje);
            inicio.setDate(inicio.getDate() - 29);
        } else if (periodo === 'mes') {
            inicio = new Date(agora.getFullYear(), agora.getMonth(), 1);
            fim = new Date(agora.getFullYear(), agora.getMonth() + 1, 1);
        }

        return lista.filter(e => {
            const d = dataDaEntrega(e);
            return d && d >= inicio && d < fim;
        });
    }

    function serieUltimosDias(entregas, quantidade = 7, agora = new Date()) {
        const fim = inicioDoDia(agora);
        const mapa = new Map();
        for (let i = quantidade - 1; i >= 0; i--) {
            const d = new Date(fim);
            d.setDate(d.getDate() - i);
            const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            mapa.set(chave, {
                chave,
                data: d,
                rotulo: DIAS_SEMANA[d.getDay()],
                dia: String(d.getDate()).padStart(2, '0'),
                faturamento: 0,
                entregas: 0,
                km: 0
            });
        }

        somenteFinalizadas(entregas).forEach(e => {
            const d = dataDaEntrega(e);
            if (!d) return;
            const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            const item = mapa.get(chave);
            if (!item) return;
            item.faturamento += numero(e?.valor);
            item.entregas += 1;
            item.km += kmEntrega(e);
        });
        return Array.from(mapa.values());
    }

    function inicioSemana(d = new Date()) {
        const x = inicioDoDia(d);
        const dia = x.getDay();
        const diff = dia === 0 ? -6 : 1 - dia;
        x.setDate(x.getDate() + diff);
        return x;
    }

    function compararSemanas(entregas, agora = new Date()) {
        const atualInicio = inicioSemana(agora);
        const atualFim = new Date(atualInicio);
        atualFim.setDate(atualFim.getDate() + 7);
        const anteriorInicio = new Date(atualInicio);
        anteriorInicio.setDate(anteriorInicio.getDate() - 7);

        const lista = somenteFinalizadas(entregas);
        const atual = lista.filter(e => {
            const d = dataDaEntrega(e);
            return d && d >= atualInicio && d < atualFim;
        });
        const anterior = lista.filter(e => {
            const d = dataDaEntrega(e);
            return d && d >= anteriorInicio && d < atualInicio;
        });

        const a = resumo(atual);
        const b = resumo(anterior);
        function delta(valorAtual, valorAnterior) {
            if (valorAnterior === 0) return valorAtual > 0 ? 100 : 0;
            return ((valorAtual - valorAnterior) / Math.abs(valorAnterior)) * 100;
        }
        return {
            atual: a,
            anterior: b,
            deltaFaturamento: delta(a.faturamento, b.faturamento),
            deltaEntregas: delta(a.entregas, b.entregas),
            deltaKm: delta(a.km, b.km),
            deltaValorHora: delta(a.valorPorHora, b.valorPorHora)
        };
    }

    function destaques(entregas) {
        const lista = somenteFinalizadas(entregas);
        const porData = new Map();
        const porHora = new Map();

        lista.forEach(e => {
            const d = dataDaEntrega(e);
            if (!d) return;
            const chaveData = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
            if (!porData.has(chaveData)) porData.set(chaveData, { data: inicioDoDia(d), faturamento: 0, entregas: 0 });
            const dia = porData.get(chaveData);
            dia.faturamento += numero(e?.valor);
            dia.entregas += 1;

            const h = d.getHours();
            if (!porHora.has(h)) porHora.set(h, { hora: h, faturamento: 0, entregas: 0 });
            const hora = porHora.get(h);
            hora.faturamento += numero(e?.valor);
            hora.entregas += 1;
        });

        const melhorDia = Array.from(porData.values()).sort((a, b) => b.faturamento - a.faturamento)[0] || null;
        const melhorHora = Array.from(porHora.values()).sort((a, b) => {
            const mediaA = a.entregas ? a.faturamento / a.entregas : 0;
            const mediaB = b.entregas ? b.faturamento / b.entregas : 0;
            return mediaB - mediaA;
        })[0] || null;

        return { melhorDia, melhorHora };
    }

    function rankingRestaurantes(entregas, limite = 5) {
        const mapa = new Map();
        somenteFinalizadas(entregas).forEach(e => {
            const nomeRaw = String(e?.estabelecimento || '').trim();
            const nome = nomeRaw || 'Sem estabelecimento';
            const chave = nome.toLocaleLowerCase('pt-BR');
            if (!mapa.has(chave)) {
                mapa.set(chave, { nome, entregas: 0, faturamento: 0, km: 0, minutos: 0 });
            }
            const r = mapa.get(chave);
            r.entregas += 1;
            r.faturamento += numero(e?.valor);
            r.km += kmEntrega(e);
            r.minutos += tempoEntregaMin(e);
        });

        return Array.from(mapa.values()).map(r => ({
            ...r,
            ticketMedio: r.entregas ? r.faturamento / r.entregas : 0,
            valorPorKm: r.km > 0 ? r.faturamento / r.km : 0,
            valorPorHora: r.minutos > 0 ? r.faturamento / (r.minutos / 60) : 0
        })).sort((a, b) => {
            if (b.faturamento !== a.faturamento) return b.faturamento - a.faturamento;
            return b.entregas - a.entregas;
        }).slice(0, limite);
    }

    window.EstatisticasV20 = {
        dataDaEntrega,
        somenteFinalizadas,
        kmEntrega,
        tempoEntregaMin,
        resumo,
        filtrarPeriodo,
        serieUltimosDias,
        compararSemanas,
        destaques,
        rankingRestaurantes
    };
}());
