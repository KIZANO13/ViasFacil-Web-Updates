// Vias Fácil V22.3.9 — lógica do painel separada do HTML
document.addEventListener('DOMContentLoaded', () => {
            const api = window.EntregaDB;
            const elDataHoje = document.getElementById('dataHoje');
            if (elDataHoje) {
                const hoje = new Date();
                elDataHoje.textContent = hoje.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
            }

            // Dados do histórico são conteúdo externo: nunca interpolar sem escape.
            function escapeHtml(value) {
                return String(value ?? '').replace(/[&<>"']/g, ch => ({
                    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
                })[ch]);
            }
            function concluida(e) {
                return ['finalizada', 'concluida', 'concluída'].includes(String(e?.status || 'finalizada').toLowerCase());
            }

            function carregarDB() { return api.carregarDB(); }
            function salvarDB(db) { return api.salvarDB(db); }

            // V20 - período selecionado para o painel de desempenho
            let statsPeriodo = localStorage.getItem('viasfacil-stats-periodo') || 'hoje';
            const statsApi = window.EstatisticasV20;

            function statsMoeda(v) {
                return `R$ ${Number(v || 0).toFixed(2).replace('.', ',')}`;
            }

            function statsDeltaHtml(valor) {
                const n = Number(valor || 0);
                const classe = n > 0.05 ? 'positivo' : n < -0.05 ? 'negativo' : '';
                const seta = n > 0.05 ? '▲' : n < -0.05 ? '▼' : '•';
                const sinal = n > 0 ? '+' : '';
                return `<span class="stats-delta ${classe}">${seta} ${sinal}${n.toFixed(0)}%</span>`;
            }

            function renderizarEstatisticas(entregas) {
                if (!statsApi) return;
                document.querySelectorAll('.stats-periodo').forEach(btn => {
                    btn.classList.toggle('ativo', btn.dataset.periodo === statsPeriodo);
                });

                const selecionadas = statsApi.filtrarPeriodo(entregas, statsPeriodo);
                const r = statsApi.resumo(selecionadas);
                document.getElementById('statFaturamento').textContent = statsMoeda(r.faturamento);
                document.getElementById('statEntregas').textContent = String(r.entregas);
                document.getElementById('statKm').textContent = `${r.km.toFixed(1).replace('.', ',')} km`;
                document.getElementById('statTempo').textContent = api.formatarTempo(r.minutos);
                document.getElementById('statTicket').textContent = statsMoeda(r.ticketMedio);
                document.getElementById('statReaisKm').textContent = statsMoeda(r.valorPorKm);
                document.getElementById('statReaisHora').textContent = statsMoeda(r.valorPorHora);
                document.getElementById('statVelMax').textContent = `${Math.round(r.velocidadeMaxima)} km/h`;

                const hoje = statsApi.resumo(statsApi.filtrarPeriodo(entregas, 'hoje'));
                const mes = statsApi.resumo(statsApi.filtrarPeriodo(entregas, 'mes'));
                document.getElementById('statHojeFaturamento').textContent = statsMoeda(hoje.faturamento);
                document.getElementById('statHojeEntregas').textContent = `${hoje.entregas} ${hoje.entregas === 1 ? 'entrega' : 'entregas'}`;
                document.getElementById('statMesFaturamento').textContent = statsMoeda(mes.faturamento);
                document.getElementById('statMesEntregas').textContent = `${mes.entregas} ${mes.entregas === 1 ? 'entrega' : 'entregas'}`;

                const serie = statsApi.serieUltimosDias(entregas, 7);
                const maior = Math.max(1, ...serie.map(d => d.faturamento));
                document.getElementById('statsGrafico7d').innerHTML = serie.map(d => {
                    const altura = d.faturamento > 0 ? Math.max(4, (d.faturamento / maior) * 100) : 3;
                    return `<div class="stats-barra-dia" title="${d.entregas} entregas • ${statsMoeda(d.faturamento)}">
                        <div class="stats-barra-valor">${d.faturamento > 0 ? `R$${Math.round(d.faturamento)}` : '0'}</div>
                        <div class="stats-barra-trilho"><div class="stats-barra-preench" style="height:${altura}%"></div></div>
                        <div class="stats-barra-rotulo">${d.rotulo}</div>
                        <div class="stats-barra-sub">${d.dia}</div>
                    </div>`;
                }).join('');

                const comp = statsApi.compararSemanas(entregas);
                document.getElementById('statsComparativoSemana').innerHTML = `
                    <div class="stats-comparativo-linha">
                        <div class="stats-comparativo-info"><span>Faturamento</span><strong>${statsMoeda(comp.atual.faturamento)} <small style="color:var(--texto-suave);font-weight:600">vs ${statsMoeda(comp.anterior.faturamento)}</small></strong></div>
                        ${statsDeltaHtml(comp.deltaFaturamento)}
                    </div>
                    <div class="stats-comparativo-linha">
                        <div class="stats-comparativo-info"><span>Entregas</span><strong>${comp.atual.entregas} <small style="color:var(--texto-suave);font-weight:600">vs ${comp.anterior.entregas}</small></strong></div>
                        ${statsDeltaHtml(comp.deltaEntregas)}
                    </div>
                    <div class="stats-comparativo-linha">
                        <div class="stats-comparativo-info"><span>Quilômetros</span><strong>${comp.atual.km.toFixed(1)} km <small style="color:var(--texto-suave);font-weight:600">vs ${comp.anterior.km.toFixed(1)} km</small></strong></div>
                        ${statsDeltaHtml(comp.deltaKm)}
                    </div>
                    <div class="stats-comparativo-linha">
                        <div class="stats-comparativo-info"><span>R$/hora</span><strong>${statsMoeda(comp.atual.valorPorHora)} <small style="color:var(--texto-suave);font-weight:600">vs ${statsMoeda(comp.anterior.valorPorHora)}</small></strong></div>
                        ${statsDeltaHtml(comp.deltaValorHora)}
                    </div>`;

                const d = statsApi.destaques(entregas);
                if (d.melhorDia) {
                    document.getElementById('statMelhorDia').textContent = d.melhorDia.data.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' });
                    document.getElementById('statMelhorDiaValor').textContent = `${statsMoeda(d.melhorDia.faturamento)} • ${d.melhorDia.entregas} entregas`;
                } else {
                    document.getElementById('statMelhorDia').textContent = '--';
                    document.getElementById('statMelhorDiaValor').textContent = 'Sem dados';
                }
                if (d.melhorHora) {
                    document.getElementById('statMelhorHorario').textContent = `${String(d.melhorHora.hora).padStart(2, '0')}h–${String((d.melhorHora.hora + 1) % 24).padStart(2, '0')}h`;
                    const media = d.melhorHora.entregas ? d.melhorHora.faturamento / d.melhorHora.entregas : 0;
                    document.getElementById('statMelhorHorarioValor').textContent = `${statsMoeda(media)} médio • ${d.melhorHora.entregas} entregas`;
                } else {
                    document.getElementById('statMelhorHorario').textContent = '--';
                    document.getElementById('statMelhorHorarioValor').textContent = 'Sem dados';
                }

                const restaurantes = statsApi.rankingRestaurantes(entregas, 5);
                const container = document.getElementById('statsRestaurantes');
                container.innerHTML = restaurantes.length ? restaurantes.map((x, i) => `
                    <div class="stats-restaurante-item">
                        <div class="stats-restaurante-topo">
                            <div class="stats-restaurante-pos">${i + 1}</div>
                            <div class="stats-restaurante-nome">${escapeHtml(x.nome)}</div>
                            <div class="stats-restaurante-valor">${statsMoeda(x.faturamento)}</div>
                        </div>
                        <div class="stats-restaurante-metricas">📦 ${x.entregas} • 🧾 ${statsMoeda(x.ticketMedio)} médio • 🛣 ${statsMoeda(x.valorPorKm)}/km • ⌚ ${statsMoeda(x.valorPorHora)}/h</div>
                    </div>`).join('') : '<div class="ranking-item">Nenhuma entrega registrada ainda.</div>';
            }

            // SINCRONIZAR REGISTROS PENDENTES DO GPS
            function processarPendenteGPS() {
                try {
                    const pendenteRaw = localStorage.getItem('painel-registro-pendente');
                    if (!pendenteRaw) return;
                    const pendente = JSON.parse(pendenteRaw);
                    api.aceitarDadosGPS(pendente);
                    localStorage.removeItem('painel-registro-pendente');
                } catch (e) {
                    console.error('Erro ao processar GPS pendente:', e);
                }
            }
            processarPendenteGPS();

            // ================= V22.2 - TEMA AUTOMÁTICO / CLARO / ESCURO =================
            const selectTema = document.getElementById('selectTema');
            const temaSistema = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

            function aplicarTema(preferencia) {
                const pref = ['automatico', 'claro', 'escuro'].includes(preferencia) ? preferencia : 'automatico';
                const efetivo = pref === 'automatico'
                    ? (temaSistema?.matches ? 'escuro' : 'claro')
                    : pref;
                document.documentElement.setAttribute('data-tema', efetivo);
                document.documentElement.setAttribute('data-tema-preferencia', pref);
                const meta = document.querySelector('meta[name="theme-color"]');
                if (meta) meta.setAttribute('content', efetivo === 'escuro' ? '#0E1A23' : '#38BDF8');
                if (selectTema) selectTema.value = pref;
            }

            let temaSalvo = localStorage.getItem('painel-tema') || 'automatico';
            // Migração transparente das versões anteriores.
            if (!['automatico', 'claro', 'escuro'].includes(temaSalvo)) temaSalvo = 'automatico';
            aplicarTema(temaSalvo);

            selectTema?.addEventListener('change', (e) => {
                const t = e.target.value;
                localStorage.setItem('painel-tema', t);
                aplicarTema(t);
            });

            const onTemaSistemaMudou = () => {
                if ((localStorage.getItem('painel-tema') || 'automatico') === 'automatico') aplicarTema('automatico');
            };
            if (temaSistema?.addEventListener) temaSistema.addEventListener('change', onTemaSistemaMudou);
            else if (temaSistema?.addListener) temaSistema.addListener(onTemaSistemaMudou);

            // ================= V22.2 - CLIMA DO ENTREGADOR =================
            const WEATHER_CODES_VF = {
                0:['☀️','Céu limpo'], 1:['🌤️','Predom. limpo'], 2:['⛅','Parcialmente nublado'], 3:['☁️','Nublado'],
                45:['🌫️','Neblina'], 48:['🌫️','Neblina'], 51:['🌦️','Garoa leve'], 53:['🌦️','Garoa'], 55:['🌧️','Garoa forte'],
                61:['🌦️','Chuva leve'], 63:['🌧️','Chuva'], 65:['🌧️','Chuva forte'], 71:['🌨️','Neve leve'], 73:['🌨️','Neve'], 75:['🌨️','Neve forte'],
                80:['🌦️','Pancadas leves'], 81:['🌧️','Pancadas'], 82:['⛈️','Pancadas fortes'], 95:['⛈️','Trovoadas'], 96:['⛈️','Trovoada com granizo'], 99:['⛈️','Trovoada forte']
            };
            let ultimaPosicaoClima = null;
            let ultimoClimaEm = 0;
            let climaEmAndamento = false;
            let timerClima = null;

            function setClimaStatus(texto, erro = false) {
                const next = document.getElementById('weatherNext');
                if (next) { next.textContent = texto; next.classList.toggle('erro', !!erro); }
            }

            function riscoClima(prob, precipitation, wind) {
                if (precipitation >= 5 || prob >= 80) return ['Chuva forte', 'alto'];
                if (precipitation >= 1 || prob >= 55) return ['Atenção à chuva', 'medio'];
                if (wind >= 35) return ['Vento forte', 'medio'];
                if (prob <= 20 && precipitation < 0.2) return ['Bom para entregas', 'baixo'];
                return ['Tempo variável', 'neutro'];
            }

            function renderizarClima(data) {
                const current = data?.current || {};
                const hourly = data?.hourly || {};
                const code = Number(current.weather_code);
                const [icon, desc] = WEATHER_CODES_VF[code] || ['🌡️','Condições atuais'];
                const temp = Number(current.temperature_2m);
                const feels = Number(current.apparent_temperature);
                const wind = Number(current.wind_speed_10m || 0);
                const nowIso = current.time || '';
                let nextIndex = 0;
                if (Array.isArray(hourly.time) && hourly.time.length) {
                    const idx = hourly.time.findIndex(t => t > nowIso);
                    nextIndex = idx >= 0 ? idx : Math.min(1, hourly.time.length - 1);
                }
                const prob = Number(hourly.precipitation_probability?.[nextIndex] ?? 0);
                const precipNext = Number(hourly.precipitation?.[nextIndex] ?? 0);
                const nextCode = Number(hourly.weather_code?.[nextIndex]);
                const nextDesc = WEATHER_CODES_VF[nextCode]?.[1] || desc;
                const [riskText, riskLevel] = riscoClima(prob, precipNext, wind);

                document.getElementById('weatherIcon').textContent = icon;
                document.getElementById('weatherTemp').textContent = Number.isFinite(temp) ? `${Math.round(temp)}°` : '--°';
                document.getElementById('weatherSummary').textContent = desc;
                document.getElementById('weatherFeels').textContent = Number.isFinite(feels) ? `${Math.round(feels)}°C` : '--°C';
                document.getElementById('weatherRain').textContent = `${Math.round(prob)}%`;
                document.getElementById('weatherWind').textContent = `${Math.round(wind)} km/h`;
                const risk = document.getElementById('weatherRisk');
                risk.textContent = riskText;
                risk.dataset.risk = riskLevel;
                setClimaStatus(`Próxima hora: ${nextDesc.toLowerCase()} • ${Math.round(prob)}% de chuva${precipNext > 0 ? ` • ${precipNext.toFixed(1).replace('.', ',')} mm` : ''}`);
            }

            let timeoutClima = null;
            function limparTimeoutClima() {
                if (timeoutClima !== null) clearTimeout(timeoutClima);
                timeoutClima = null;
            }
            async function buscarClima(lat, lng, forcar = false) {
                if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
                if (climaEmAndamento) return;
                const agora = Date.now();
                if (!forcar && agora - ultimoClimaEm < 10 * 60 * 1000) {
                    try { window.AndroidBridge?.pararLocalizacaoNativa?.(); } catch (_) {}
                    return;
                }
                climaEmAndamento = true;
                setClimaStatus('Atualizando previsão…');

                // No APK, a consulta é feita pelo Android nativo para evitar as restrições
                // de rede de páginas file:///android_asset em alguns WebViews.
                try {
                    if (window.AndroidBridge?.buscarClima) {
                        window.AndroidBridge.buscarClima(Number(lat), Number(lng));
                        limparTimeoutClima();
                        timeoutClima = setTimeout(() => {
                            climaEmAndamento = false;
                            setClimaStatus('O clima demorou para responder. Tente atualizar.', true);
                            try { window.AndroidBridge?.pararLocalizacaoNativa?.(); } catch (_) {}
                        }, 20000);
                        return;
                    }
                } catch (e) {
                    console.warn('Clima nativo indisponível; usando fallback web.', e);
                }

                // Fallback para abrir o painel fora do APK durante desenvolvimento/testes.
                try {
                    const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lng)}&current=temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&hourly=precipitation_probability,precipitation,weather_code&forecast_days=1&timezone=auto`;
                    const resp = await fetch(url, { cache: 'no-store' });
                    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
                    renderizarClima(await resp.json());
                    ultimoClimaEm = Date.now();
                } catch (e) {
                    console.warn('Falha ao atualizar clima', e);
                    setClimaStatus('Não foi possível atualizar o clima. Toque em ↻ Atualizar para tentar novamente.', true);
                } finally {
                    limparTimeoutClima();
                    climaEmAndamento = false;
                    try { window.AndroidBridge?.pararLocalizacaoNativa?.(); } catch (_) {}
                }
            }

            window.onAndroidWeatherData = raw => {
                try {
                    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
                    renderizarClima(data || {});
                    ultimoClimaEm = Date.now();
                } catch (e) {
                    console.warn('Resposta de clima nativa inválida', e);
                    setClimaStatus('Não foi possível interpretar os dados do clima.', true);
                } finally {
                    limparTimeoutClima();
                    climaEmAndamento = false;
                    try { window.AndroidBridge?.pararLocalizacaoNativa?.(); } catch (_) {}
                }
            };

            window.onAndroidWeatherError = message => {
                limparTimeoutClima();
                climaEmAndamento = false;
                console.warn('Falha no clima nativo:', message);
                setClimaStatus('Não foi possível atualizar o clima. Toque em ↻ Atualizar para tentar novamente.', true);
                try { window.AndroidBridge?.pararLocalizacaoNativa?.(); } catch (_) {}
            };

            function solicitarPosicaoClima(forcar = false) {
                if (forcar) ultimoClimaEm = 0;
                setClimaStatus('Obtendo sua localização…');
                const bridge = window.AndroidBridge;
                if (bridge && typeof bridge.hasLocationPermission === 'function') {
                    try {
                        if (bridge.hasLocationPermission()) bridge.iniciarLocalizacaoNativa?.();
                        else {
                            setClimaStatus('Permita a localização para mostrar o clima da sua região.', true);
                            bridge.solicitarPermissaoLocalizacao?.();
                        }
                        return;
                    } catch (erro) { console.warn('Falha ao obter posição nativa:', erro); }
                }
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        pos => buscarClima(pos.coords.latitude, pos.coords.longitude, forcar),
                        () => setClimaStatus('Localização indisponível para o clima.', true),
                        { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
                    );
                } else setClimaStatus('Localização indisponível neste navegador.', true);
            }

            window.onAndroidNativeLocation = (lat, lng) => {
                ultimaPosicaoClima = { lat: Number(lat), lng: Number(lng) };
                buscarClima(ultimaPosicaoClima.lat, ultimaPosicaoClima.lng, false);
            };
            window.onAndroidLocationPermission = granted => { if (granted) solicitarPosicaoClima(true); };
            window.atualizarClimaV22 = () => solicitarPosicaoClima(true);

            // Atualiza ao abrir e a cada 15 min. O GPS é ligado apenas para obter uma posição recente.
            setTimeout(() => solicitarPosicaoClima(false), 700);
            timerClima = setInterval(() => solicitarPosicaoClima(false), 15 * 60 * 1000);

            document.querySelectorAll('.stats-periodo').forEach(btn => {
                btn.addEventListener('click', () => {
                    statsPeriodo = btn.dataset.periodo || 'hoje';
                    localStorage.setItem('viasfacil-stats-periodo', statsPeriodo);
                    renderizarPainel();
                });
            });

            function renderizarPainel() {
                const db = carregarDB();
                const entregas = db.entregas || [];
                const finalizadas = statsApi.somenteFinalizadas(entregas);
                const totalKm = finalizadas.reduce((acc, r) => acc + (Number(r.kmReal || r.kmEstimado || r.km) || 0), 0);
                const totalViagens = finalizadas.length;
                const maxVel = finalizadas.reduce((acc, r) => Math.max(acc, Number(r.velocidadeMaxima || r.velMax) || 0), 0);
                const totalTempoMin = finalizadas.reduce((acc, r) => {
                    const real = Number(r.tempoRealMin || 0);
                    const estimado = Number(r.tempoEstimadoMin || api.minutosDeTempo(r.tempo) || 0);
                    return acc + (real > 0 ? real : estimado);
                }, 0);

                document.getElementById('cardTotalKm').textContent = `${totalKm.toFixed(1)} km`;
                document.getElementById('cardTotalViagens').textContent = totalViagens;
                document.getElementById('cardVelMax').textContent = `${Math.round(maxVel)} km/h`;
                document.getElementById('cardTempoTotal').textContent = api.formatarTempo(totalTempoMin);

                renderizarEstatisticas(entregas);
                try { window.MapaCalorV223?.atualizar(entregas); } catch (e) { console.warn('Mapa de calor:', e); }

                const inputMeta = document.getElementById('inputMeta');
                const metaVal = Number(db.metaKm) || 500;
                inputMeta.value = metaVal;
                const kmMes = statsApi.resumo(statsApi.filtrarPeriodo(finalizadas, 'mes')).km;
                const pctMeta = Math.min(100, Math.round((kmMes / metaVal) * 100));
                document.getElementById('barraMeta').style.width = `${pctMeta}%`;
                document.getElementById('textoMetaProgresso').textContent = `${kmMes.toFixed(1)} / ${metaVal} km (${pctMeta}%)`;
                inputMeta.onchange = () => { db.metaKm = Number(inputMeta.value) || 500; salvarDB(db); renderizarPainel(); };

                const listaRanking = document.getElementById('listaRanking');
                const top3 = [...finalizadas].sort((a, b) => (b.kmReal || b.kmEstimado || 0) - (a.kmReal || a.kmEstimado || 0)).slice(0, 3);
                listaRanking.innerHTML = top3.length ? top3.map((r, i) => `
                    <div class="ranking-item">
                        <div class="ranking-pos">${i + 1}º</div>
                        <div class="ranking-data">${r.estabelecimento ? `🏪 ${escapeHtml(r.estabelecimento)}<br>` : ''}${escapeHtml(r.enderecoColeta || r.origem)} → ${escapeHtml(r.enderecoEntrega || r.destino)}</div>
                        <div class="ranking-valor">${Number(r.kmReal || r.kmEstimado || 0).toFixed(1)} km</div>
                    </div>`).join('') : '<div class="ranking-item">Nenhuma entrega registrada.</div>';

                const gridConquistas = document.getElementById('gridConquistas');
                const conquistas = [
                    { titulo: 'Primeira Entrega', desc: 'Registre a 1ª entrega', batida: totalViagens >= 1, icon: '📦' },
                    { titulo: 'Estradeiro', desc: 'Percorra 100 km no total', batida: totalKm >= 100, icon: '🛣️' },
                    { titulo: 'Motorista Ativo', desc: 'Realize 10 entregas', batida: totalViagens >= 10, icon: '🏆' },
                    { titulo: 'Meta Batida', desc: 'Alcance sua meta mensal', batida: kmMes >= metaVal, icon: '🎯' }
                ];
                gridConquistas.innerHTML = conquistas.map(c => `
                    <div class="conquista-card ${c.batida ? 'desbloqueada' : 'bloqueada'}">
                        <div class="conquista-topo"><span class="conquista-icone">${c.icon}</span><div><div class="conquista-titulo">${c.titulo}</div><div class="conquista-desc">${c.desc}</div></div></div>
                    </div>`).join('');

                const listaHist = document.getElementById('listaHistorico');
                const buscaVal = (document.getElementById('buscaHistorico').value || '').toLowerCase();
                const filtrados = entregas.filter(r => {
                    const txt = `${r.estabelecimento || ''} ${r.enderecoColeta || r.origem || ''} ${r.enderecoEntrega || r.destino || ''}`.toLowerCase();
                    return txt.includes(buscaVal);
                });
                listaHist.innerHTML = filtrados.length ? filtrados.map(r => {
                    const kmReal = Number(r.kmReal || 0);
                    const kmEstimado = Number(r.kmEstimado || r.km || 0);
                    const kmExibido = kmReal > 0 ? kmReal : kmEstimado;
                    const tempoRealMin = Number(r.tempoRealMin || 0);
                    const tempoEstimadoMin = Number(r.tempoEstimadoMin || 0);
                    const valor = Number(r.valor || 0);
                    const valorKm = Number(r.valorPorKmReal || r.valorPorKm || (kmExibido > 0 ? valor / kmExibido : 0));
                    const valorHora = Number(r.valorPorHoraReal || r.valorPorHora || (tempoRealMin > 0 ? valor / (tempoRealMin / 60) : 0));
                    const maxVelEntrega = Number(r.velocidadeMaxima || r.velMax || 0);
                    const tempoExibido = tempoRealMin > 0 ? api.formatarTempo(tempoRealMin) : (r.tempoEstimado || r.tempo || '--');
                    const realLabel = kmReal > 0 ? 'real' : 'estimado';
                    const detalhesReais = [
                        kmReal > 0 && kmEstimado > 0 ? `estimado ${kmEstimado.toFixed(1)} km` : '',
                        tempoRealMin > 0 && tempoEstimadoMin > 0 ? `estimado ${Math.round(tempoEstimadoMin)} min` : '',
                        maxVelEntrega > 0 ? `máx. ${Math.round(maxVelEntrega)} km/h` : ''
                    ].filter(Boolean).join(' • ');

                    return `<div class="historico-item">
                        <div>
                            <div class="historico-data">${r.estabelecimento ? `🏪 ${escapeHtml(r.estabelecimento)}` : '📦 Entrega'} </div>
                            <div class="historico-detalhes">📍 ${escapeHtml(r.enderecoColeta || r.origem)} → 🏠 ${escapeHtml(r.enderecoEntrega || r.destino)}</div>
                            <div class="historico-detalhes">📅 ${escapeHtml(r.data || 'Data não informada')} ${r.hora ? `• ${escapeHtml(r.hora)}` : ''} | ⏱️ ${escapeHtml(tempoExibido)}</div>
                            <div class="historico-detalhes">📏 ${kmExibido.toFixed(1)} km ${realLabel}${detalhesReais ? ` • ${detalhesReais}` : ''}</div>
                            ${valor ? `<div class="historico-detalhes">💵 R$/km ${valorKm.toFixed(2).replace('.', ',')} • R$/h ${valorHora.toFixed(2).replace('.', ',')}</div>` : ''}
                        </div>
                        <div style="font-weight:700;color:var(--accent1);text-align:right">${valor ? `R$ ${valor.toFixed(2).replace('.', ',')}` : ''}<br>${concluida(r) ? '<span class="vf-status-concluida">✓ Concluída</span>' : `<button type="button" class="btn-historico-gps" data-id="${escapeHtml(r.id)}" style="margin-top:6px;padding:5px 8px;border:1px solid currentColor;border-radius:8px;background:transparent;color:inherit;cursor:pointer;font-size:11px;">🗺️ GPS</button>`}</div>
                    </div>`;
                }).join('') : '<div class="historico-item">Nenhuma entrega encontrada.</div>';
            }

            document.getElementById('buscaHistorico').addEventListener('input', renderizarPainel);

            const modal = document.getElementById('modalOverlay');
            const ids = ['regEstabelecimento','regOrigem','regDestino','regValor','regKm','regTempo'];
            function atualizarIndicadoresForm() {
                const valor = Number(document.getElementById('regValor').value) || 0;
                const km = Number(document.getElementById('regKm').value) || 0;
                const tempo = api.minutosDeTempo(document.getElementById('regTempo').value);
                const rpm = km > 0 ? valor / km : 0;
                const rph = tempo > 0 ? valor / (tempo / 60) : 0;
                document.getElementById('regIndicadores').textContent = `R$/km: ${rpm ? `R$ ${rpm.toFixed(2).replace('.', ',')}` : '--'} | R$/h: ${rph ? `R$ ${rph.toFixed(2).replace('.', ',')}` : '--'}`;
            }
            ids.forEach(id => document.getElementById(id)?.addEventListener('input', atualizarIndicadoresForm));
            document.getElementById('btnAbrirModal').onclick = () => { modal.classList.add('aberto'); atualizarIndicadoresForm(); };
            document.getElementById('btnFecharModal').onclick = () => modal.classList.remove('aberto');

            function lerDadosFormulario(status = 'finalizada') {
                return {
                    origemSistema: 'manual',
                    status,
                    estabelecimento: document.getElementById('regEstabelecimento').value.trim(),
                    enderecoColeta: document.getElementById('regOrigem').value.trim(),
                    enderecoEntrega: document.getElementById('regDestino').value.trim(),
                    valor: Number(document.getElementById('regValor').value) || 0,
                    kmEstimado: Number(document.getElementById('regKm').value) || 0,
                    tempoEstimadoMin: api.minutosDeTempo(document.getElementById('regTempo').value),
                    tempoEstimado: document.getElementById('regTempo').value || '00:00'
                };
            }

            function limparFormulario() {
                document.getElementById('formRegistro').reset();
                document.getElementById('regTempo').value = '00:30';
                atualizarIndicadoresForm();
            }

            document.getElementById('formRegistro').onsubmit = (e) => {
                e.preventDefault();
                if (!api.tempoValido(document.getElementById('regTempo').value)) {
                    document.getElementById('regTempo').reportValidity();
                    return;
                }
                api.adicionarEntrega(lerDadosFormulario('finalizada'));
                modal.classList.remove('aberto');
                limparFormulario();
                renderizarPainel();
            };

            function ativarGpsParaEntrega(entrega) {
                try {
                    const bridge = window.AndroidBridge;
                    if (concluida(entrega)) {
                        alert('Entregas concluídas não podem ser reiniciadas. Cadastre uma nova entrega.');
                        return false;
                    }
                    if (!bridge || typeof bridge.ativarEntregaManual !== 'function') {
                        alert('A navegação está disponível apenas no aplicativo Android.');
                        return false;
                    }
                    if (!bridge.ativarEntregaManual(JSON.stringify(entrega))) {
                        alert('Existe outra entrega em navegação ou os endereços estão incompletos. Finalize a entrega atual antes de abrir outra.');
                        return false;
                    }
                    return true;
                } catch (e) {
                    console.error('Não foi possível iniciar a navegação para esta entrega.', e);
                    alert('Não foi possível preparar a navegação.');
                    return false;
                }
            }

            document.getElementById('btnSalvarEGPS')?.addEventListener('click', () => {
                const form = document.getElementById('formRegistro');
                if (!form.reportValidity()) return;
                if (!api.tempoValido(document.getElementById('regTempo').value)) {
                    document.getElementById('regTempo').reportValidity();
                    return;
                }
                // Verifica aceite nativo antes de persistir; falha não cria entrega órfã.
                const proposta = api.normalizarEntrega(lerDadosFormulario('aguardando_gps'));
                if (!ativarGpsParaEntrega(proposta)) return;
                try {
                    api.adicionarEntrega(proposta);
                    api.abrirEntregaNoGPS(proposta.id);
                } catch (erro) {
                    // O Android já possui a entrega ativa e poderá sincronizá-la na conclusão.
                    console.error('Entrega ativada pelo Android, mas não persistida no WebView:', erro);
                    alert('GPS iniciado, porém não foi possível salvar no painel. Libere espaço para evitar problemas com o histórico.');
                }
                modal.classList.remove('aberto');
                limparFormulario();
                window.location.href = 'gps-native://open';
            });

            document.getElementById('listaHistorico')?.addEventListener('click', (event) => {
                const btn = event.target.closest('.btn-historico-gps');
                if (!btn) return;
                const id = btn.dataset.id;
                if (!id) return;
                const entrega = api.obterEntrega(id);
                if (entrega && !concluida(entrega) && ativarGpsParaEntrega(entrega) && api.abrirEntregaNoGPS(id)) {
                    window.location.href = 'gps-native://open';
                }
            });


            // V22.3 - mapa de calor próprio baseado no histórico local
            try { window.MapaCalorV223?.iniciar(); } catch (e) { console.warn('Falha ao iniciar mapa de calor:', e); }

            // ================= V21 - ATUALIZAÇÃO AUTOMÁTICA DO PAINEL =================
            let ultimaAssinaturaPainel = '';
            let ultimoRefreshEm = 0;

            function assinaturaDadosPainel() {
                return localStorage.getItem('painel-db') || '';
            }

            function mostrarStatusAtualizacao(origem = 'auto') {
                const el = document.getElementById('painelAtualizadoEm');
                if (!el) return;
                const agora = new Date();
                const hora = agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                const rotulo = origem === 'manual' ? 'Atualizado manualmente' :
                    origem === 'retorno-app' ? 'Atualizado ao voltar ao app' :
                    origem === 'sincronizacao' ? 'Nova entrega sincronizada' : 'Atualizado automaticamente';
                el.textContent = `${rotulo} • ${hora}`;
                ultimoRefreshEm = Date.now();
            }

            function atualizarPainelV21(origem = 'auto', forcar = false) {
                // Processa também qualquer dado que tenha ficado pendente no armazenamento WebView.
                processarPendenteGPS();
                const assinatura = assinaturaDadosPainel();
                const mudou = assinatura !== ultimaAssinaturaPainel;
                if (forcar || mudou) {
                    renderizarPainel();
                    ultimaAssinaturaPainel = assinaturaDadosPainel();
                    mostrarStatusAtualizacao(origem);
                }
                return mudou;
            }

            window.atualizarPainelV21 = atualizarPainelV21;

            document.getElementById('btnAtualizarPainel')?.addEventListener('click', () => {
                try { window.AndroidBridge?.sincronizarPainel?.(); } catch (_) {}
                atualizarPainelV21('manual', true);
                try { window.atualizarClimaV22?.(); } catch (_) {}
            });

            // Verifica alterações sem redesenhar a tela se nada mudou.
            setInterval(() => {
                if (document.visibilityState === 'visible') atualizarPainelV21('auto', false);
            }, 3000);

            document.addEventListener('visibilitychange', () => {
                if (document.visibilityState === 'visible') {
                    atualizarPainelV21('retorno-app', true);
                    if (Date.now() - ultimoClimaEm >= 10 * 60 * 1000) solicitarPosicaoClima(false);
                }
            });
            window.addEventListener('focus', () => atualizarPainelV21('retorno-app', true));
            window.addEventListener('pageshow', () => atualizarPainelV21('retorno-app', true));

            renderizarPainel();
            ultimaAssinaturaPainel = assinaturaDadosPainel();
            mostrarStatusAtualizacao('auto');
        });
