/* Vias Fácil 22.5.0 — interface para atualização Web autenticada.
 * Não baixa nem executa código diretamente: todas as validações são nativas.
 */
(function () {
    'use strict';
    function byId(id) { return document.getElementById(id); }
    function setStatus(message) { const el = byId('vfUpdateStatus'); if (el) el.textContent = String(message || ''); }
    window.onViasUpdateEvent = function (evt) {
        if (!evt || typeof evt !== 'object') return;
        if (evt.current) { const v = byId('vfUpdateCurrent'); if (v) v.textContent = evt.current; }
        if (evt.status) setStatus(evt.status);
        const rollback = byId('vfUpdateRollback');
        if (rollback && typeof evt.hasExternal === 'boolean') rollback.hidden = !evt.hasExternal;
        const install = byId('vfUpdateInstall');
        if (install) {
            install.hidden = evt.type !== 'available';
            install.disabled = evt.type !== 'available';
        }
        const check = byId('vfUpdateCheck');
        if (check) check.disabled = evt.type === 'checking' || evt.type === 'downloading';
        if (evt.type === 'available' && evt.notes) {
            const notes = byId('vfUpdateNotes');
            if (notes) notes.textContent = 'Novidades: ' + evt.notes;
        }
        if (evt.type === 'error') {
            const notes = byId('vfUpdateNotes');
            if (notes) notes.textContent = 'A versão instalada continua preservada.';
        }
    };
    document.addEventListener('DOMContentLoaded', function () {
        const native = window.AndroidBridge;
        const check = byId('vfUpdateCheck');
        const install = byId('vfUpdateInstall');
        const rollback = byId('vfUpdateRollback');
        if (!check || !install || !rollback) return;
        if (!native || typeof native.consultarAtualizacoesWeb !== 'function') {
            setStatus('Atualizador disponível apenas no aplicativo Android.');
            check.disabled = true;
        } else {
            try {
                byId('vfUpdateCurrent').textContent = native.versaoWebAtual();
                rollback.hidden = !native.temAtualizacaoWebAtiva();
            }
            catch (_) { /* Estado opcional; não interfere no painel. */ }
        }
        try {
            if (!native || !native.atualizadorConfigurado()) {
                setStatus('Servidor de atualizações ainda não configurado neste APK.');
                check.disabled = true;
            } else {
                // Verifica automaticamente uma vez ao dia, sem instalar silenciosamente.
                const key = 'viasfacil-last-web-update-check-v2250';
                const last = Number(localStorage.getItem(key) || 0);
                const now = Date.now();
                if ((!last || now - last > 24 * 60 * 60 * 1000) && navigator.onLine !== false) {
                    localStorage.setItem(key, String(now));
                    native.consultarAtualizacoesWeb();
                }
            }
        } catch (_) { /* Falha de auto-check não impede uso do painel. */ }
        check.addEventListener('click', function () {
            setStatus('Consultando servidor de atualizações…');
            install.hidden = true;
            try { native.consultarAtualizacoesWeb(); }
            catch (_) { setStatus('Não foi possível consultar o atualizador.'); }
        });
        rollback.addEventListener('click', function () {
            if (!window.confirm('Voltar à interface Web anterior? Seus dados serão mantidos.')) return;
            try { native.reverterAtualizacaoWeb(); }
            catch (_) { setStatus('Não foi possível reverter a atualização.'); }
        });
        install.addEventListener('click', function () {
            if (!window.confirm('Instalar atualização da interface Web agora? A navegação não deve estar ativa.')) return;
            install.disabled = true;
            setStatus('Baixando e verificando o pacote assinado…');
            try { native.instalarAtualizacaoWeb(); }
            catch (_) { install.disabled = false; setStatus('Não foi possível iniciar a atualização.'); }
        });
    });
    window.ViasUpdaterClientReady = true;
})();
