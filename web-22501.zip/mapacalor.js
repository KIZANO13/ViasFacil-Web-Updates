/* V22.3 — Mapa de calor próprio do Vias Facil
 * Usa somente o histórico local já salvo pelo aplicativo.
 * Não altera a navegação GPS nem a rota em andamento.
 */
(function () {
    'use strict';

    const STORAGE = {
        ativo: 'viasfacil-heat-ativo',
        modo: 'viasfacil-heat-modo',
        periodo: 'viasfacil-heat-periodo'
    };

    const ENGINE_VERSION = '2239';
    const ENGINE_KEY = 'viasfacil-heat-engine-version';

    // Mudanças de versão do motor não sobrescrevem a preferência do usuário.
    if (localStorage.getItem(ENGINE_KEY) !== ENGINE_VERSION) {
        localStorage.setItem(ENGINE_KEY, ENGINE_VERSION);
    }

    const DEFAULT_CENTER = [-23.5505, -46.6333];
    const GRID_DEG = 0.006; // ~600 m em latitude: agrupa pontos próximos em uma zona útil.

    let mapa = null;
    let camadaPontos = null;
    let tileLayer = null;
    let iniciado = false;
    let entregasAtuais = [];
    let ativo = lerBool(STORAGE.ativo, false);
    let modo = localStorage.getItem(STORAGE.modo) || 'coletas';
    let periodo = localStorage.getItem(STORAGE.periodo) || '7d';

    function lerBool(chave, padrao) {
        const raw = localStorage.getItem(chave);
        if (raw == null) return padrao;
        return raw === 'true';
    }

    function n(v, fallback = 0) {
        if (v === null || v === undefined || String(v).trim() === '') return fallback;
        const x = Number(v);
        return Number.isFinite(x) ? x : fallback;
    }

    function moeda(v) {
        return Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    function decimal(v, casas = 1) {
        return Number(v || 0).toLocaleString('pt-BR', {
            minimumFractionDigits: casas,
            maximumFractionDigits: casas
        });
    }

    function dataEntrega(e) {
        if (window.EstatisticasV20?.dataDaEntrega) return window.EstatisticasV20.dataDaEntrega(e);
        const vals = [e?.entregaFinalizadaEm, e?.finalizadoEm, e?.coletaRealizadaEm, e?.criadoEm];
        for (const v of vals) {
            if (!v) continue;
            const d = new Date(v);
            if (!Number.isNaN(d.getTime())) return d;
        }
        return null;
    }

    function finalizadas(lista) {
        if (window.EstatisticasV20?.somenteFinalizadas) return window.EstatisticasV20.somenteFinalizadas(lista);
        return (Array.isArray(lista) ? lista : []).filter(e => {
            const s = String(e?.status || 'finalizada').toLowerCase();
            return s === 'finalizada' || s === 'concluida' || s === 'concluída';
        });
    }

    function porPeriodo(lista) {
        if (window.EstatisticasV20?.filtrarPeriodo) {
            return window.EstatisticasV20.filtrarPeriodo(lista, periodo === 'hoje' ? 'hoje' : periodo);
        }
        const base = finalizadas(lista);
        if (periodo === 'tudo') return base;
        const agora = new Date();
        const hoje = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate());
        let inicio = new Date(hoje);
        if (periodo === '7d') inicio.setDate(inicio.getDate() - 6);
        else if (periodo === '30d') inicio.setDate(inicio.getDate() - 29);
        return base.filter(e => {
            const d = dataEntrega(e);
            return d && d >= inicio && d < new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + 1);
        });
    }

    function coordValida(lat, lng) {
        return Number.isFinite(lat) && Number.isFinite(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 && !(lat === 0 && lng === 0);
    }

    function coordsDaEntrega(e, tipo) {
        if (tipo === 'entrega') {
            const lat = n(e?.latEntrega, NaN);
            const lng = n(e?.lngEntrega, NaN);
            return coordValida(lat, lng) ? { lat, lng } : null;
        }
        const lat = n(e?.latColeta, NaN);
        const lng = n(e?.lngColeta, NaN);
        return coordValida(lat, lng) ? { lat, lng } : null;
    }

    function kmEntrega(e) {
        if (window.EstatisticasV20?.kmEntrega) return n(window.EstatisticasV20.kmEntrega(e));
        const real = n(e?.kmReal);
        return real > 0 ? real : n(e?.kmEstimado ?? e?.km);
    }

    function chaveCelula(lat, lng) {
        const gy = Math.round(lat / GRID_DEG);
        const gx = Math.round(lng / GRID_DEG);
        return `${gy}:${gx}`;
    }

    function gerarZonas(lista) {
        const filtradas = porPeriodo(lista);
        const celulas = new Map();
        const usaDestino = modo === 'entregas';

        filtradas.forEach(e => {
            // Coletas, faturamento e R$/km usam a coleta como referência.
            const c = coordsDaEntrega(e, usaDestino ? 'entrega' : 'coleta');
            if (!c) return;
            const key = chaveCelula(c.lat, c.lng);
            if (!celulas.has(key)) {
                celulas.set(key, {
                    latSoma: 0,
                    lngSoma: 0,
                    pontos: 0,
                    entregas: 0,
                    faturamento: 0,
                    km: 0
                });
            }
            const z = celulas.get(key);
            z.latSoma += c.lat;
            z.lngSoma += c.lng;
            z.pontos += 1;
            z.entregas += 1;
            z.faturamento += n(e?.valor);
            z.km += kmEntrega(e);
        });

        const zonas = Array.from(celulas.values()).map(z => {
            const rpkm = z.km > 0 ? z.faturamento / z.km : 0;
            let metrica = z.entregas;
            if (modo === 'faturamento') metrica = z.faturamento;
            else if (modo === 'rpkm') metrica = rpkm;
            return {
                lat: z.latSoma / z.pontos,
                lng: z.lngSoma / z.pontos,
                entregas: z.entregas,
                faturamento: z.faturamento,
                km: z.km,
                rpkm,
                metrica
            };
        }).filter(z => z.metrica > 0);

        zonas.sort((a, b) => b.metrica - a.metrica);
        return { zonas, totalRegistros: filtradas.length };
    }

    function garantirMapa() {
        if (mapa || !window.L) return !!mapa;
        const el = document.getElementById('mapaCalorMapa');
        if (!el) return false;
        mapa = L.map(el, {
            zoomControl: true,
            attributionControl: true,
            preferCanvas: true
        }).setView(DEFAULT_CENTER, 11);
        tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap'
        }).addTo(mapa);
        camadaPontos = L.layerGroup().addTo(mapa);
        setTimeout(() => mapa?.invalidateSize?.(), 80);
        return true;
    }

    function labelZona(z) {
        if (modo === 'faturamento') return moeda(z.faturamento).replace('R$', 'R$').replace(/\s/g, ' ');
        if (modo === 'rpkm') return `R$ ${decimal(z.rpkm, 2)}/km`;
        return `${z.entregas}x`;
    }

    function tituloModo() {
        if (modo === 'entregas') return '🏠 Zona de entregas';
        if (modo === 'faturamento') return '💰 Zona de faturamento';
        if (modo === 'rpkm') return '🛣️ Zona de eficiência';
        return '📦 Zona de coletas';
    }

    function popupZona(z) {
        return `<div class="heat-vf-popup">
            <strong>${tituloModo()}</strong>
            <div>📦 ${z.entregas} entrega${z.entregas === 1 ? '' : 's'}</div>
            <div>💰 ${moeda(z.faturamento)}</div>
            <div>📏 ${decimal(z.km, 1)} km</div>
            <div>🛣️ ${moeda(z.rpkm)}/km</div>
        </div>`;
    }

    function desenhar(zonas) {
        if (!garantirMapa()) return;
        camadaPontos.clearLayers();
        const empty = document.getElementById('heatEmpty');
        const resumo = document.getElementById('heatResumo');

        if (!zonas.length) {
            empty?.classList.add('visivel');
            if (resumo) resumo.textContent = 'Nenhuma entrega com coordenadas neste período.';
            setTimeout(() => mapa.invalidateSize(), 80);
            return;
        }
        empty?.classList.remove('visivel');

        const max = Math.max(...zonas.map(z => z.metrica), 1);
        const bounds = [];
        zonas.forEach((z, idx) => {
            const intensidade = Math.max(0.12, Math.min(1, z.metrica / max));
            const size = Math.round(72 + intensidade * 92);
            const alpha = (0.42 + intensidade * 0.48).toFixed(2);
            const html = `<div class="heat-vf-spot" style="--heat-size:${size}px;--heat-core:${alpha}">
                <div class="heat-vf-blob"></div>
                <div class="heat-vf-core"></div>
                <div class="heat-vf-label">${labelZona(z)}</div>
            </div>`;
            const icon = L.divIcon({
                className: 'heat-vf-marker',
                html,
                iconSize: [170, 170],
                iconAnchor: [85, 85]
            });
            const marker = L.marker([z.lat, z.lng], { icon, zIndexOffset: 500 - idx });
            marker.bindPopup(popupZona(z), { maxWidth: 230, closeButton: true });
            marker.addTo(camadaPontos);
            bounds.push([z.lat, z.lng]);
        });

        if (bounds.length === 1) mapa.setView(bounds[0], 14, { animate: false });
        else mapa.fitBounds(bounds, { padding: [34, 34], maxZoom: 15, animate: false });
        setTimeout(() => mapa.invalidateSize(), 80);
        if (resumo) resumo.textContent = `${zonas.length} zona${zonas.length === 1 ? '' : 's'} • ${zonas.reduce((s, z) => s + z.entregas, 0)} entrega${zonas.reduce((s, z) => s + z.entregas, 0) === 1 ? '' : 's'}`;
    }

    function atualizarAjuda() {
        const ajuda = document.getElementById('heatAjuda');
        if (!ajuda) return;
        const textos = {
            coletas: 'Coletas mostram onde você mais retira pedidos. Toque em uma área quente para ver os detalhes.',
            entregas: 'Entregas mostram as regiões onde você mais finaliza corridas.',
            faturamento: 'Faturamento usa o ponto de coleta como referência e destaca as regiões que mais geraram receita.',
            rpkm: 'R$/km usa o ponto de coleta como referência e destaca as regiões com melhor retorno por quilômetro.'
        };
        ajuda.textContent = textos[modo] || textos.coletas;
    }

    function aplicarEstadoVisual() {
        const card = document.getElementById('heatCard');
        const toggle = document.getElementById('heatToggle');
        const texto = document.getElementById('heatToggleText');
        if (!card || !toggle || !texto) return;
        card.classList.toggle('desligado', !ativo);
        toggle.classList.toggle('ativo', ativo);
        toggle.setAttribute('aria-pressed', ativo ? 'true' : 'false');
        texto.textContent = ativo ? 'ON' : 'OFF';
        document.querySelectorAll('[data-heat-modo]').forEach(b => b.classList.toggle('ativo', b.dataset.heatModo === modo));
        document.querySelectorAll('[data-heat-periodo]').forEach(b => b.classList.toggle('ativo', b.dataset.heatPeriodo === periodo));
        atualizarAjuda();
        if (ativo) setTimeout(() => mapa?.invalidateSize?.(), 80);
    }

    function renderizar() {
        aplicarEstadoVisual();
        if (!ativo) return;
        const { zonas } = gerarZonas(entregasAtuais);
        desenhar(zonas);
    }

    function bindEventos() {
        document.getElementById('heatToggle')?.addEventListener('click', () => {
            ativo = !ativo;
            localStorage.setItem(STORAGE.ativo, String(ativo));
            aplicarEstadoVisual();
            if (ativo) renderizar();
        });

        document.querySelectorAll('[data-heat-modo]').forEach(btn => {
            btn.addEventListener('click', () => {
                modo = btn.dataset.heatModo || 'coletas';
                localStorage.setItem(STORAGE.modo, modo);
                renderizar();
            });
        });

        document.querySelectorAll('[data-heat-periodo]').forEach(btn => {
            btn.addEventListener('click', () => {
                periodo = btn.dataset.heatPeriodo || '7d';
                localStorage.setItem(STORAGE.periodo, periodo);
                renderizar();
            });
        });

        window.addEventListener('resize', () => mapa?.invalidateSize?.());
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && ativo) setTimeout(() => mapa?.invalidateSize?.(), 100);
        });
    }

    function iniciar() {
        if (iniciado) return;
        iniciado = true;
        bindEventos();
        aplicarEstadoVisual();
        if (ativo) garantirMapa();
    }

    function atualizar(entregas) {
        entregasAtuais = Array.isArray(entregas) ? entregas : [];
        if (!iniciado) iniciar();
        renderizar();
    }

    window.MapaCalorV223 = {
        iniciar,
        atualizar,
        isAtivo: () => ativo,
        setAtivo: value => {
            ativo = !!value;
            localStorage.setItem(STORAGE.ativo, String(ativo));
            renderizar();
        }
    };
}());
