/* Vias Fácil 22.5.2 — painel compacto do atualizador Web.
 * Todas as validações de arquivo e assinatura continuam no Android nativo.
 */
(function () {
    'use strict';
    const byId = (id) => document.getElementById(id);
    let native = null;
    let check = null, install = null, dismiss = null;
    let rollback = null, rollbackAvailable = null, more = null;
    let statusTimer = null;
    let hasExternal = false;
    let hasAvailable = false;
    let busy = false;

    function status(message, kind, temporary) {
        const el = byId('vfUpdateStatus');
        if (!el) return;
        if (statusTimer !== null) { clearTimeout(statusTimer); statusTimer = null; }
        el.textContent = String(message || '');
        el.hidden = !message;
        const card = byId('vfUpdateCard');
        if (card && kind === 'error') card.dataset.state = 'error';
        if (temporary && message) {
            statusTimer = setTimeout(() => { el.hidden = true; statusTimer = null; }, 5500);
        }
    }

    function setExternal(value) {
        hasExternal = !!value;
        if (rollback) rollback.hidden = !hasExternal;
        if (rollbackAvailable) rollbackAvailable.hidden = !hasExternal;
        if (more) {
            more.hidden = !hasExternal;
            if (!hasExternal) more.open = false;
        }
    }

    function setVersion(version) {
        if (!version) return;
        const value = String(version);
        const current = byId('vfUpdateCurrent');
        const installed = byId('vfUpdateInstalled');
        if (current) current.textContent = value;
        if (installed) installed.textContent = value;
    }

    function view(available) {
        const card = byId('vfUpdateCard');
        const compact = byId('vfUpdateCompact');
        const details = byId('vfUpdateDetails');
        hasAvailable = !!available;
        if (card) card.dataset.state = hasAvailable ? 'available' : 'compact';
        if (compact) compact.hidden = hasAvailable;
        if (details) details.hidden = !hasAvailable;
        if (install) install.hidden = !hasAvailable;
        if (more) more.open = false;
        if (!hasAvailable) {
            const note = byId('vfUpdateNotes');
            if (note) note.textContent = '';
        }
    }

    function setBusy(value) {
        busy = !!value;
        if (check) check.disabled = busy;
        if (install) install.disabled = busy || !hasAvailable;
        if (dismiss) dismiss.disabled = busy;
        if (rollback) rollback.disabled = busy;
        if (rollbackAvailable) rollbackAvailable.disabled = busy;
    }

    function rollbackNow() {
        if (!hasExternal || busy || !native || typeof native.reverterAtualizacaoWeb !== 'function') return;
        if (!window.confirm('Voltar à interface Web anterior? Seus dados serão mantidos.')) return;
        if (more) more.open = false;
        setBusy(true);
        status('Voltando à versão anterior…');
        try { native.reverterAtualizacaoWeb(); }
        catch (_) { setBusy(false); status('Não foi possível reverter a atualização.', 'error', true); }
    }

    window.onViasUpdateEvent = function (evt) {
        if (!evt || typeof evt !== 'object') return;
        if (evt.current) setVersion(evt.current);
        if (typeof evt.hasExternal === 'boolean') setExternal(evt.hasExternal);
        const type = evt.type;
        if (type === 'available') {
            view(true);
            const label = byId('vfUpdateAvailable');
            if (label) label.textContent = evt.status || 'Nova versão disponível';
            const notes = byId('vfUpdateNotes');
            if (notes) notes.textContent = evt.notes ? 'Novidades: ' + evt.notes : 'Melhorias para o painel.';
            status('');
            setBusy(false);
        } else if (type === 'checking') {
            view(false);
            setBusy(true);
            status(evt.status || 'Procurando atualizações…');
        } else if (type === 'downloading') {
            // O card permanece expandido para informar o que está acontecendo.
            if (!hasAvailable) view(true);
            setBusy(true);
            status(evt.status || 'Baixando atualização…');
        } else if (type === 'current') {
            view(false);
            setBusy(false);
            status(evt.status || 'Nenhuma atualização disponível.', '', true);
        } else if (type === 'error') {
            // Uma falha no download não deve esconder o botão para repetir a tentativa.
            setBusy(false);
            const card = byId('vfUpdateCard');
            if (card) card.dataset.state = 'error';
            status(evt.status || 'Não foi possível verificar as atualizações.', 'error', !hasAvailable);
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        native = window.AndroidBridge;
        check = byId('vfUpdateCheck');
        install = byId('vfUpdateInstall');
        rollback = byId('vfUpdateRollback');
        rollbackAvailable = byId('vfUpdateRollbackAvailable');
        more = byId('vfUpdateMore');
        dismiss = byId('vfUpdateDismiss');
        if (!check || !install || !rollback || !rollbackAvailable || !dismiss || !more) return;

        view(false);
        if (!native || typeof native.consultarAtualizacoesWeb !== 'function') {
            check.disabled = true;
            status('Atualizador disponível apenas no aplicativo Android.', 'error');
        } else {
            try {
                setVersion(native.versaoWebAtual());
                setExternal(native.temAtualizacaoWebAtiva());
            } catch (_) { /* Informação visual opcional; painel continua. */ }
        }

        let configured = false;
        try { configured = !!(native && native.atualizadorConfigurado()); }
        catch (_) { configured = false; }
        if (!configured) {
            check.disabled = true;
            status('Servidor de atualizações não configurado neste APK.', 'error');
        } else {
            try {
                // Preserva a mesma chave de controle da V22.5.0: no máximo uma consulta automática ao dia.
                const key = 'viasfacil-last-web-update-check-v2250';
                const last = Number(localStorage.getItem(key) || 0);
                const now = Date.now();
                if ((!last || now - last > 24 * 60 * 60 * 1000) && navigator.onLine !== false) {
                    localStorage.setItem(key, String(now));
                    native.consultarAtualizacoesWeb();
                }
            } catch (_) { /* Sem internet ou storage, apenas verificação manual. */ }
        }

        check.addEventListener('click', function () {
            if (!configured || busy) return;
            view(false);
            setBusy(true);
            status('Consultando atualizações…');
            try { native.consultarAtualizacoesWeb(); }
            catch (_) { setBusy(false); status('Falha ao consultar o servidor.', 'error', true); }
        });
        install.addEventListener('click', function () {
            if (!hasAvailable || busy || !native) return;
            if (!window.confirm('Aplicar esta atualização do painel? Não inicie uma entrega durante a instalação.')) return;
            setBusy(true);
            status('Baixando e verificando o pacote assinado…');
            try { native.instalarAtualizacaoWeb(); }
            catch (_) { setBusy(false); status('Não foi possível iniciar a atualização.', 'error'); }
        });
        dismiss.addEventListener('click', function () {
            if (busy) return;
            view(false);
            setBusy(false);
            status('');
        });
        rollback.addEventListener('click', rollbackNow);
        rollbackAvailable.addEventListener('click', rollbackNow);
    });
    window.ViasUpdaterClientReady = true;
})();
